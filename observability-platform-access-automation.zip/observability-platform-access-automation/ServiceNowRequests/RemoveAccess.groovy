def ldapOUMappings = [
    'ldap-manager-password-devopsauthz': 'CN=svc.devops-authz-mgr,OU=System,OU=Regeneron Accounts,DC=regeneron,DC=regn,DC=com'    
]
pipeline {
    agent { label 'cli-tools'}
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
    }
    environment {
        LDAP_HOST = "ldaps://regn-ldaps.regeneron.com"
        LDAP_PORT = 636
        // Define the URL of the repository you want to clone and modify
        BITBUCKET_REPO_URL = 'ssh://git@ritscm.regeneron.com/iteso/observability-platform-access-database.git'
        // Use the ID of the credentials you stored in Jenkins
        BITBUCKET_CREDENTIALS_ID = 'bitbucket-publish'
    }
    parameters {
        string(name: 'SNOW_ID', defaultValue: '', description: 'Service Now Ticket ID')
        string(name: 'BU_NAME', defaultValue: '', description: 'Name of Business Unit')
        string(name: 'TEAM_NAME', defaultValue: '', description: 'Team Name')
        choice(name: 'ENVIRONMENT', choices:['Dev','Test','Prod'], description: 'Select Environment either Prod or Dev or Test')
        string(name: 'REQUESTED_FOR', defaultValue: '', description: 'User ID')
        choice(name: 'ROLE', choices:['Editor','Viewer'], description: 'Select a Role to provide access')
    }

    stages {
        stage('Clone Observability Access Database Repository') {
            steps {
                script {
                  sshagent (credentials:['bitbucket-publish']) { 
                                   sh """
                                     cd ..
                                     git clone ssh://git@ritscm.regeneron.com/iteso/observability-platform-access-database.git
                                   """  
                  }
                }
            }    
         }

        stage('Remove Access') {
            steps { script {
                sshagent (credentials:['bitbucket-publish']) { 
                    for (user in params.REQUESTED_FOR.split(',')) {
                        def trimedUser = user.trim()
                        if (trimedUser != "") {
                            // Initialize credentialsId variable
                            def credentialsId = 'ldap-manager-password-devopsauthz' 
                            withCredentials([string(credentialsId: credentialsId, variable: 'BINDING_PW')]) {
                                def binding_dn = ldapOUMappings[credentialsId]
                                sh """
                                   export "BINDING_DN=${binding_dn}"
                                   python modules/GrafanaAutomation.py  ga-remove-access-snow-request --snow_id '${params.SNOW_ID}' --access_type 'remove_access' --bu_name '${params.BU_NAME}' --team_name '${params.TEAM_NAME}' --environment '${params.ENVIRONMENT}' --role '${params.ROLE}' --user '${trimedUser}'
                                   """ 
                            }
                        }
                    }
               }
            }
          }
        }
        stage('Commit and Push') {
            steps {
                script {
                        sshagent (credentials:['bitbucket-publish']) {
                        withCredentials([sshUserPrivateKey(credentialsId: 'bitbucket-publish',
                            usernameVariable: 'SSH_USER_NAME',
                            keyFileVariable: 'SSH_KEY')]) {
                        sh """
                           cd ..
                           cd observability-platform-access-database
                           echo `date`>> fileupdate.txt
                           git config user.email '${SSH_USER_NAME}@regeneron.com' 
                           git config user.name ${SSH_USER_NAME}
                           git add .
                           git commit -m "feat: UserAccess.yaml file updated via Jenkins pipeline"
                           git push origin master
                        """
                        }
                   }
                }
            }
        } 
    }
}
