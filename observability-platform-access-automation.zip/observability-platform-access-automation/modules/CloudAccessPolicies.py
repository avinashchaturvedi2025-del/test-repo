import requests
import os
import json

# Grafana Cloud Configuration
GC_ACCESS_POLICY_TOKEN = os.environ.get('GC_AP_TOKEN', '') 
GRAFANA_CLOUD_API_URL = 'https://www.grafana.com/api/v1/accesspolicies?region=prod-us-east-0'

HEADERS = {
    "Authorization": f"Bearer {GC_ACCESS_POLICY_TOKEN }",
    "Content-Type": "application/json"
}

def create_access_policy_token(access_policy_id):
    GRAFANA_CLOUD_TOKEN_URL = "https://www.grafana.com/api/v1/tokens?region=prod-us-east-0"

    payload = {
    "accessPolicyId": access_policy_id,
    "name": f'{access_policy_id}-token',
    "displayName": f'{access_policy_id}-Token',
    "expiresAt": "2025-08-08T22:05:46.958Z"
    }
    
    # Make the API request to create the access policy token
    response = requests.post(GRAFANA_CLOUD_TOKEN_URL, json=payload, headers=HEADERS)

    # Check the response
    if response.status_code == 200:
        print("Access policy token created successfully.")
        data = response.json()
        os.environ['GC_AP_TOKEN'] = data['token']
    else:
        print("Error creating access policy token.", response.status_code, response.text)

def create_grafana_saas_access_policy(access_policy_name,stack_id,lbac_details):
    # Define the access policy payload
    parsed_list = lbac_details.split(";")
    payload = {
            "name": access_policy_name.lower(),
            "displayName": access_policy_name.lower(),
            "scopes": ["metrics:read", "logs:read", "traces:read", "alerts:read"],
            "realms": [
                {
                    "type": "stack",
                    "identifier": stack_id,
                    "labelPolicies": [
                    ]
                }
            ]
        }
    for i in parsed_list:
       seldic = {"selector": i}
       payload['realms'][0]['labelPolicies'].append(seldic)
       
    response = requests.post(GRAFANA_CLOUD_API_URL, json=payload, headers=HEADERS)
    # Check the response
    if response.status_code == 200:
        print("Access policy created successfully:", response.json())
        data = response.json()
        create_access_policy_token(data['id'])
    else:
        print("Error creating access policy:", response.status_code, response.text)

def get_access_policies():
    grafana_url = 'https://www.grafana.com/api/v1/accesspolicies?region=prod-us-east-0'
    response = requests.get(grafana_url, headers=HEADERS, verify=False)
    # Check the response
    if response.status_code == 200:
        data = response.json()
        return data['items']
    else:
        print("Error creating access policy:", response.status_code, response.text)

def get_access_policy_id(policy_name):
    policy_data = get_access_policies()
    for i in range(len(policy_data)):
        if policy_data[i]['name'] == policy_name:
           return policy_data[i]['id']


def delete_access_policy(access_policy_name):
    access_policy_id = get_access_policy_id(access_policy_name)
    """
    Deletes a Grafana Cloud Access Policy.
    """
    print(f"Attempting to delete access policy with ID: {access_policy_id}")
    # It's more likely the endpoint is structured like the following, based on Terraform provider info:
    API_URL = f"https://grafana.com/api/v1/accesspolicies/{access_policy_id}?region=prod-us-east-0"

    try:
        response = requests.delete(API_URL, headers=HEADERS)
        response.raise_for_status()  # Raises an exception for bad status codes (4xx or 5xx)

        if response.status_code == 204:
            print("Access policy deleted successfully.")
        else:
            print(f"Unexpected status code: {response.status_code}")
            print("Response:", response.text)

    except requests.exceptions.HTTPError as errh:
        print(f"Http Error: {errh}")
        print("Response Body:", errh.response.text)
    except requests.exceptions.ConnectionError as errc:
        print(f"Error Connecting: {errc}")
    except requests.exceptions.Timeout as errt:
        print(f"Timeout Error: {errt}")
    except requests.exceptions.RequestException as err:
        print(f"Oops: Something Else: {err}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")


