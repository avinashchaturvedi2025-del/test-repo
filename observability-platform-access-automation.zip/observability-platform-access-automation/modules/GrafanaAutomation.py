import requests
import os
import click
import json
import DataSource
import NestedFolder
import Team
import ldapManager
import CloudAccessPolicies
import SnowRequestUserAccess
import SnowRequestTeams

# Grafana Cloud Configuration
API_TOKEN = os.environ.get('GRAFANA_API_KEY', '')

HEADERS = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json"
}

@click.group()
def cli():
    pass

@click.command()
@click.option('--ds_name', required=True, help='Data Source Name')
@click.option('--ds_type', required=True, help='Data Source Type')   
@click.option('--ds_url', required=True, help='Data Source URL')  
@click.option('--grafana_base_url', required=True, help='Grafana Base URL')
@click.option('--access_policy_user', required=True, help='Stack ID used as Policy User')  
def ga_create_data_source(ds_name,ds_type,ds_url,grafana_base_url,access_policy_user):
    DataSource.create_data_source(ds_name,ds_type,ds_url,grafana_base_url,access_policy_user)



@click.command()
@click.option('--team_id', required=True, help='Team ID')
@click.option('--data_source_id',required=True, help="Data Source ID")
@click.option('--permission_id', required=True, help='Permission ID # 1 = Viewer, 2 = Editor, 4 = Admin')   
@click.option('--grafana_base_url', required=True, help='Grafana Base URL') 
def ga_add_data_source_permissions(team_id,data_source_id,permission_id, grafana_base_url):
    DataSource.add_data_source_permissions(team_id,data_source_id,permission_id, grafana_base_url)


@click.command()
@click.option('--bu_name', required=True, help='BU Name of the team')
@click.option('--folder_name', required=True, help='Folder Name')    
@click.option('--grafana_base_url', required=True, help='Grafana Base URL')  
def ga_nested_folder(bu_name,folder_name,grafana_base_url):
    NestedFolder.nested_folder(bu_name,folder_name,grafana_base_url)

@click.command()
@click.option('--team_id', required=True, help='BU Name of the team')
@click.option('--folder_uid', required=True, help='Folder UID') 
@click.option('--permission_id', required=True, help='# Permission levels: 1=View, 2=Edit, 4=Admin')  
@click.option('--grafana_base_url', required=True, help='Grafana Base URL') 
def ga_folder_permissions(team_id,folder_uid,permission_id,grafana_base_url):
    NestedFolder.set_folder_permission_for_team(permission_id,team_id,folder_uid,grafana_base_url)

@click.command()
@click.option('--team_name', required=True, help='Name of the team')
@click.option('--external_group_id', required=True, help='External Group ID')
@click.option('--grafana_base_url', required=True, help='Grafana Base URL')
def ga_sync_external_group_to_team(team_name, external_group_id,grafana_base_url):
    Team.sync_external_group_to_team(team_name, external_group_id,grafana_base_url)


@click.command()
@click.option('--group_name', '-g', help="Name of group to put under listed OU")
@click.option('--ou', '-o', help="Name of OU to put group inside")
@click.option('--description', '-d', default="", help="Description of group purpose")
def ga_create_group_in_ou(group_name, ou, description):
    ldapManager.create_group_in_ou(group_name, ou, description)


@click.command()
@click.option('--group_name', '-g', help="Name of group to remove under listed OU")
@click.option('--ou', '-o', help="Name of OU to to remove group from")
def ga_remove_group_from_ou(group_name, ou):
    ldapManager.remove_group_from_ou(group_name, ou)


@click.command()
@click.option('--user', '-u', help="User sAMAccountName to add to group")
@click.option('--group', '-g', help="Group sAMAccountName to add user to")
@click.option('--user_type', '-g', help="Group sAMAccountName to add user to")
def ga_add_user_to_group(user, group, user_type=""):
    ldapManager.add_user_to_group(user, group, user_type="")

@click.command()
@click.option('--user', '-u', help="User sAMAccountName to remove from group")
@click.option('--group', '-g', help="Group sAMAccountName to remove user from")
def ga_remove_user_from_group(user, group):
    ldapManager.remove_user_from_group(user, group)

@click.command()
@click.option('--name', '-n', help="sAMAccountName to search")
def ga_lookup(name):
    ldapManager.lookup(name)

@click.command()
@click.option('--user_name_list', help="--user_name_list '['test2', 'test3']' (sAMAccountName to check if account is deactivated format)")
def ga_lookup_disabled_accounts(user_name_list):
    ldapManager.lookup_disabled_accounts(user_name_list)


@click.command()
@click.option('--name', '-n', help="sAMAccountName to search")
def ga_get_users_from_group(name):
    ldapManager.get_users_from_group(name)


@click.command()
@click.option('--name', '-n', help="sAMAccountName to search")
def ga_check_if_group_exist(name):
    ldapManager.check_if_group_exist(name)

@click.command()
@click.option('--access_policy_name', required=True, help='Access Policy Name')
@click.option('--stack_id', required=True, help='Stack ID')
def ga_create_grafana_saas_access_policy(access_policy_name,stack_id):
    CloudAccessPolicies.create_grafana_saas_access_policy(access_policy_name,stack_id)

@click.command()
@click.option('--snow_id', required=True, help='Service Now Ticket Number')
@click.option('--access_type', required=True, help=' Provide or Remove Access')
@click.option('--bu_name', required=True, help='BU Name')
@click.option('--team_name', required=True, help=' Name of the team')
@click.option('--environment', required=True, help=' Environment')
@click.option('--role', required=True, help=' Role Access to provide')
@click.option('--user', required=True, help='User ID')
def ga_provide_access(snow_id,access_type,bu_name,team_name,environment,role,user):
    SnowRequestUserAccess.provide_access(snow_id,access_type,bu_name,team_name,environment,role,user)

@click.command()
@click.option('--environment', required=True, help=' Environment')
def ga_provide_access_from_config(environment):
    SnowRequestUserAccess.provide_access_from_config(environment)

@click.command()
@click.option('--environment', required=True, help=' Environment')
def ga_remove_access_from_config(environment):
    SnowRequestUserAccess.remove_access_from_config(environment)


@click.command()
@click.option('--snow_id', required=True, help='Service Now Ticket Number')
@click.option('--access_type', required=True, help=' Provide or Remove Access')
@click.option('--bu_name', required=True, help='BU Name')
@click.option('--team_name', required=True, help=' Name of the team')
@click.option('--environment', required=True, help=' Environment')
@click.option('--role', required=True, help=' Role Access to provide')
@click.option('--user', required=True, help='User ID')
def ga_remove_access(snow_id,access_type,bu_name,team_name,environment,role,user):
    SnowRequestUserAccess.remove_access(snow_id,access_type,bu_name,team_name,environment,role,user)

@click.command()
@click.option('--snow_id', help='Service Now Ticket Number')
@click.option('--bu_name', required=True, help='Name of the Business Unit')
@click.option('--team_name', required=True, help='Name of the team')
@click.option('--owner_email', required=True, help='Email of the team contact')
@click.option('--grafana_base_url', required=True, help='Grafana Base URL')
@click.option('--folder_name', required=True, help='folder name')
@click.option('--lbac_details', required=True, help='lbac details')
@click.option('--invoke_type', required=True, help='Invoke type can be "FromConfig" or "FromServiceNow" or "FromJenkinsJob"')
@click.option('--environment', required=True, help='Environment')
def ga_create_team(snow_id,bu_name,team_name,owner_email,grafana_base_url,environment,folder_name,lbac_details,invoke_type):
    SnowRequestTeams.create_team(snow_id,bu_name, team_name, owner_email,grafana_base_url,environment,folder_name,lbac_details,invoke_type)


@click.command()
@click.option('--environment', required=True, help=' Environment')
@click.option('--grafana_base_url', required=True, help='Grafana Base URL')
def ga_create_team_from_config(environment,grafana_base_url):
    Team.create_team_from_config(environment,grafana_base_url)

    
cli.add_command(ga_create_data_source)
cli.add_command(ga_add_data_source_permissions)
cli.add_command(ga_nested_folder)
cli.add_command(ga_folder_permissions)
cli.add_command(ga_sync_external_group_to_team)
cli.add_command(ga_create_group_in_ou)
cli.add_command(ga_add_user_to_group)
cli.add_command(ga_remove_user_from_group)
cli.add_command(ga_remove_group_from_ou)
cli.add_command(ga_lookup)
cli.add_command(ga_lookup_disabled_accounts)
cli.add_command(ga_get_users_from_group)
cli.add_command(ga_check_if_group_exist)
cli.add_command(ga_create_grafana_saas_access_policy)
cli.add_command(ga_provide_access)
cli.add_command(ga_remove_access)
cli.add_command(ga_create_team)
cli.add_command(ga_create_team_from_config)
cli.add_command(ga_provide_access)
cli.add_command(ga_remove_access)
cli.add_command(ga_provide_access_from_config)
cli.add_command(ga_remove_access_from_config)

if __name__ == '__main__':
   cli()