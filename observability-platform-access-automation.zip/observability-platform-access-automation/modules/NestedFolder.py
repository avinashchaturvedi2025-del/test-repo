import requests
import os
import json

# Grafana Cloud Configuration
API_TOKEN = os.environ.get('GRAFANA_API_KEY', '')

HEADERS = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json",
    "Accept": "application/json",
}


def get_folders(grafana_base_url,stack_id):
    url = f'{grafana_base_url}/apis/folder.grafana.app/v1beta1/namespaces/stacks-{stack_id}/folders'
    response = requests.get(url, headers=HEADERS)
    if response.status_code == 200:
        data = response.json()
        return data['items']
    else:
        print("Failed to Fetch folder UID:", response.status_code, response.text)

def get_bu_uid(folders_data,bu_name):
    bu_uid = ''
    for i in range(len(folders_data)):
        if folders_data[i]['spec']['title'] == bu_name:
            bu_uid = folders_data[i]['metadata']['name']
            print(bu_uid)
            return bu_uid

def get_folder_uid(grafana_base_url,stack_id,folder_name,bu_name):
    folders_data = get_folders(grafana_base_url,stack_id)
    print(folders_data)
    bu_uid = get_bu_uid(folders_data,bu_name)
    if bu_name:
        for i in range(len(folders_data)):
            if folders_data[i]['spec']['title'] == bu_name:
                bu_uid = folders_data[i]['metadata']['name']
                print(bu_uid)

    for i in range(len(folders_data)):
         if bu_name and 'grafana.app/folder' in folders_data[i]['metadata']['annotations']:
             print(folders_data[i]['spec']['title'])
             if folders_data[i]['spec']['title'] == folder_name and folders_data[i]['metadata']['annotations']['grafana.app/folder'] == bu_uid:
                   print(folders_data[i]['metadata']['name'])
                   return folders_data[i]['metadata']['name']
             else:
               print('testing')
         else:
             if folders_data[i]['spec']['title'] == folder_name:
                 print(folders_data[i]['metadata']['name'])
                 return folders_data[i]['metadata']['name']

def create_folder(folder_name, grafana_base_url,bu_name=None, parent_folder_id=None):
    url = f"{grafana_base_url}/api/folders"
    
    # Create folder payload
    data = {
        "title": folder_name,
        "overwrite": False # Set to True if you want to overwrite existing folder with the same name
    }
    
    if parent_folder_id:
        uid = bu_name.lower().replace("","-") + "-" + folder_name.lower().replace(" ", "-")
        data["parentUid"] = parent_folder_id # Specify parent folder UID for nested folders
        data["uid"]: uid
        print(data)
    else:
        uid = folder_name.lower().replace(" ", "-")
        data["uid"]: uid
        print(data)

    response = requests.post(url, json=data, headers=HEADERS)
    
    if response.status_code == 200:
        folder_info = response.json()
        print(f"Folder '{folder_name}' created successfully.")
        print(f"Folder UID: {folder_info['uid']}")
        return folder_info
    else:
        print(f"Failed to create folder '{folder_name}': {response.status_code}")
        print(response.json())
        return None

def remove_folder(folder_uid,stack_id,grafana_base_url):
    url = f"{grafana_base_url}/apis/folder.grafana.app/v1beta1/namespaces/stacks-{stack_id}/folders/{folder_uid}"
    response = requests.delete(url,headers=HEADERS)

    if response.status_code == 200:
        print(f"Folder '{folder_uid}' deleted successfully.")
    else:
        print(f"Failed to delete folder '{folder_uid}': {response.status_code}")
        print(response.json())


     
def nested_folder(bu_name,stack_id,folder_name,grafana_base_url):
    # Step 0:
    parent_folder_id = get_folder_uid(grafana_base_url,stack_id,bu_name,'')
    print(parent_folder_id)
    # Step 1: Create the parent folder
    if parent_folder_id:
        print('BU Name already exists ${parent_folder_id}' )
    else:
        parent_folder = create_folder(bu_name,grafana_base_url)
        parent_folder_id = parent_folder["uid"]

    if parent_folder_id:
        # Step 2: Create nested folder inside the parent folder
        nested_folder = create_folder(folder_name,grafana_base_url, bu_name, parent_folder_id)
        return nested_folder['uid']

        # if parent_folder:
        #     print(f"Nested Folder created inside {parent_folder['title']}")

def set_folder_permission_for_team(permission_level: int, team_id: int,folder_uid,grafana_base_url):
    """
    Sets a specific permission level for a team on a Grafana folder.

    Permission Levels:
    1 = View
    2 = Edit
    4 = Admin
    """
    api_endpoint = f"/api/folders/{folder_uid}/permissions"
    full_url = f"{grafana_base_url}{api_endpoint}"
    
    HEADERS = {
        "Authorization": f"Bearer {API_TOKEN}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    # Payload to grant 'Edit' permission to the specified team
    # This will overwrite existing permissions for the team on this folder.
    payload = {
        "items": [
            {
                "teamId": int(team_id),
                "permission": int(permission_level), # 1 for View, 2 for Edit, 4 for Admin
            }
        ]
    }

    print(f"Attempting to set permission level '{permission_level}' for Team ID '{team_id}' on Folder UID '{folder_uid}'...")

    try:
        response = requests.post(full_url, headers=HEADERS, data=json.dumps(payload))
        # Raises an exception for bad status codes (4xx or 5xx)
        response.raise_for_status()
        print(" Folder permissions updated successfully!")
        print(json.dumps(response.json(), indent=2))

    except requests.exceptions.HTTPError as errh:
        print(f" HTTP Error: {errh}")
        print(f"Response Body: {response.text}")
    except requests.exceptions.RequestException as err:
        print(f" Request Error: {err}")







