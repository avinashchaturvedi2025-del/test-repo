import json
import os
from tabulate import tabulate
import time
from ldap3 import Server, Connection
from ldap3.extend.microsoft.addMembersToGroups import ad_add_members_to_groups
from ldap3.extend.microsoft.removeMembersFromGroups import ad_remove_members_from_groups
import ast

LDAP_HOST = os.environ.get('LDAP_HOST', 'ldaps://regn-ldaps.regeneron.com')
LDAP_PORT = os.environ.get('LDAP_PORT', 636)
BINDING_DN = os.environ.get('BINDING_DN', 'CN=svc.okta-authz-mgr,OU=System,OU=Regeneron Accounts,DC=regeneron,DC=regn,DC=com')
BINDING_PW = os.environ.get('BINDING_PW', '')
BASE_RAD_OU = os.environ.get('BASE_RAD_OU', 'OU=OktaAuthz,OU=Application Groups,OU=Regeneron Groups,DC=regeneron,DC=regn,DC=com')


def create_group_in_ou(group_name, ou, description):
    ldap = LdapExecutor()
    group_exist = ldap.check_if_group_exist(group_name)
    if not group_exist:
        ldap.add_group_to_ou(group_name, ou, description=description)
    else:
        print("Group already exists")

def remove_group_from_ou(group_name, ou):
    ldap = LdapExecutor()
    ldap.remove_group_from_ou(group_name, ou)


def add_user_to_group(user, group, user_type=""):
    ldap = LdapExecutor()
    ldap.add_user_to_group(user, group, user_type)


def remove_user_from_group(user, group):
    ldap = LdapExecutor()
    ldap.remove_user_from_group(user, group)

def lookup(name):
    ldap = LdapExecutor()
    data = ldap.get_object_from_samaccountname(name)

    results = []
    for k, v in data.items():
        newval = v
        if isinstance(v, list):
            newval = "\n".join([str(value) for value in v])
        results.append([k, newval])
    print(tabulate(results, tablefmt='plain'))

def lookup_disabled_accounts(user_name_list):
    # Parse the string input into a list
    try:
        user_name_list = ast.literal_eval(user_name_list)
    except (ValueError, SyntaxError) as e:
        click.echo(f"Error parsing user_name_list: {e}")
        return

    deactivated_users_list = []
    active_users_list = []
    ldap = LdapExecutor()
    for username in user_name_list:
        data = ldap.get_object_from_samaccountname(username)
        if data:
            if 'Regeneron Disabled Accounts' in data['distinguishedName']:
                print(f"{username} is deactivated in LDAP")
                deactivated_users_list.append(username)
            else:
                print(f"{username} is active in LDAP")
                active_users_list.append(username)
    
    with open('deactivated_users_list.txt', 'w') as file:
        file.writelines([item + '\n' for item in deactivated_users_list])
    with open('active_users_list.txt', 'w') as file:
        file.writelines([item + '\n' for item in active_users_list])

def get_users_from_group(name):
    ldap = LdapExecutor()
    group_exists = ldap.check_if_group_exist(name)
    if group_exists:
        users = ldap.get_users_from_group(name)
        if len(users) == 0:
            print(f"No users present in the group {name}")
        else:
            print(f"Users in group {name} are {users}")
    else:
        print(f"Group {name} does not exist")


def check_if_group_exist(name):
    ldap = LdapExecutor()
    ldap.check_if_group_exist(name)


class LdapExecutor:
    def __init__(self):
        self.server = Server(LDAP_HOST, port=int(LDAP_PORT), use_ssl=True)
        self.conn = Connection(self.server,
                               BINDING_DN,
                               BINDING_PW,
                               auto_bind='DEFAULT',
                               authentication='SIMPLE',
                               raise_exceptions=True)
        self.conn.bind()

    @staticmethod
    def build_filter(ldap_filters, operator='|'):
        """
        :param ldap_filters: List of filters in format of python dicts, [{'samaccountname': 'john.prewitt'}, {'samaccountname': 'derek.yamadang'}]
        :param operator: How to combine the filter members
        :return: filter string
        """
        filter_list = []
        for ldap_filter in ldap_filters:
            for key, val in ldap_filter.items():
                filter_list.append(f"({key}={val})")

        if len(filter_list) == 1:
            return filter_list[0]
        else:
            return f"({operator}{''.join(filter_list)})"

    def get_object_dn_from_samaccountname(self, samaccountname):
        return self.get_object_from_samaccountname(samaccountname)['distinguishedName']

    def get_users_from_group(self, samaccountname):
        base_dn = "DC=regeneron,DC=regn,DC=com"
        self.conn.search(base_dn, f'(sAMAccountName={samaccountname})', attributes= ['member'])
        #response = json.loads(self.conn.response_to_json())
        #print(response)
        users = []
        for entry in self.conn.entries:
            for member in entry.member.values:
                self.conn.search(
                    search_base=base_dn,
                    search_filter=f'(distinguishedName={member})',
                    attributes=[
                        'sAMAccountName'
                    ]
                )

                user_sAMAccountName = self.conn.entries[0].sAMAccountName.values

                users.append(user_sAMAccountName[0].lower())
        return users

    def check_if_group_exist(self, samaccountname):
        base_dn = "DC=regeneron,DC=regn,DC=com"
        self.conn.search(base_dn, f'(sAMAccountName={samaccountname})', attributes= ['sAMAccountName'])
        response = json.loads(self.conn.response_to_json())
        print(f"entries: {response['entries']}")
        return response['entries']


    def get_object_from_samaccountname(self, samaccountname):
        base_dn = "DC=regeneron,DC=regn,DC=com"
        self.conn.search(base_dn, f'(sAMAccountName={samaccountname})', attributes='*')

        response = json.loads(self.conn.response_to_json())
        if len(response['entries']) == 1:
            return response['entries'][0]['attributes']
        elif len(response['entries']) == 0:
            raise Exception(f"No entries returned for sAMAccountName: {samaccountname}")
        else:
            raise Exception(f"Multiple entries returned for sAMAccountName: {samaccountname}; {response['entries']}")

    def add_group_to_ou(self, group_name, ou, description=""):
        dl_group_dn = f"CN={group_name},{ou}"
        object_class = "group"
        attr = {
            'cn': group_name,
            'description': description,
            'name': group_name,
            'sAMAccountName': group_name,
            'managedBy': self.get_object_dn_from_samaccountname("derek.yamadang"),
            'extensionAttribute1': False,
            'extensionAttribute2': False,
            'extensionAttribute3': False,
            'extensionAttribute8': False,
        }
        try:
            self.conn.add(dl_group_dn, object_class, attr)
        except Exception as e:
            print(e)
            exit(1)
        print(f"Result : {self.conn.result}")
        if self.conn.result["result"] == 0:
            print(f"{group_name} successfully added to {ou}")
        if self.conn.result["result"] != 0:
            print("Group creation failed")
            exit(1)

    def remove_group_from_ou(self, group_name, ou):
        group_dn = f"CN={group_name},{ou}"
        try:
            self.conn.delete(group_dn)
            print(f"Result : {self.conn.result}")
            if self.conn.result['result'] == 0:
                print(f"{group_name} successfully removed from {ou}")
        except Exception as e:
            print("Unable to delete the group from ou")
            print("Error:{}".format(e))
            exit(1)

    def add_user_to_group(self, user_sam, group_sam, user_type):
        try:
            sleep_count = 0
            # If group is created through automation it will take some time to reflect in ldap
            # so before adding a user make sure the group is created by sleeping for 60 sec
            while sleep_count < 60:
                if user_type != "":
                    group_exist = self.check_if_group_exist(user_sam)
                else:
                    group_exist = self.check_if_group_exist(group_sam)
                if not group_exist:
                    print("Sleeping for 1 sec. Sleep count : {}".format(sleep_count))
                    time.sleep(1)
                else:
                    break
                sleep_count += 1
            print(self.get_object_dn_from_samaccountname(user_sam))
            print(self.get_object_dn_from_samaccountname(group_sam))
            if 'Regeneron Disabled Accounts' in self.get_object_dn_from_samaccountname(user_sam):
                #Do not add disabled users to LDAP groups
                print(f"User {user_sam} is disabled")
                return
            ad_add_members_to_groups(self.conn,
                                    self.get_object_dn_from_samaccountname(user_sam),
                                    self.get_object_dn_from_samaccountname(group_sam),
                                    raise_error=True
                                    )
            print(f"Result : {self.conn.result}")
            if self.conn.result['result'] == 0:
                print(f"{user_sam} successfully added to {group_sam}")
        except Exception as e:
            print("Error:{}".format(e))
            exit(1)

    def remove_user_from_group(self, user_sam, group_sam):
        try:
            ad_remove_members_from_groups(self.conn,
                                        self.get_object_dn_from_samaccountname(user_sam),
                                        self.get_object_dn_from_samaccountname(group_sam),
                                        True,
                                        raise_error=True
                                        )
            print(f"Result : {self.conn.result}")
            if self.conn.result['result'] == 0:
                print(f"{user_sam} removed from {group_sam}")
        except Exception as e:
            print(f"Unable to remove user {user_sam} from group {group_sam}")
            print("Error:{}".format(e))
            exit(1)




