import requests
import os
import click
import json

# Grafana Cloud Configuration
API_TOKEN = os.environ.get('GRAFANA_API_KEY', '')

HEADERS = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json"
}
@click.group()
def cli():
    pass

@click.command()
@click.option('--grafanabaseurl', required=True, help='Grafana Base URL')
@click.option('--stackid', required=True, help='Grafana Cloud Stack ID like test - 292932 ')
def get_dashboards(grafanabaseurl,stackid):
    # Grafana Cloud Configuration
    API_TOKEN = os.environ.get('GRAFANA_API_KEY', '')
    HEADERS = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json"
    }
    url = f"{grafanabaseurl}/apis/dashboard.grafana.app/v1beta1/namespaces/stacks-{stackid}/dashboards/"
    print(url)
    response = requests.get(url, headers=HEADERS)
    if response.status_code == 200:
        ldashboards = response.json()
        if ldashboards:
          for dash in ldashboards:
              print(f"Title: {dash['title']}, UID: {dash['uid']}")

    else:
        print(f"Failed to list dashboards: {response.status_code}")
        return None


def create_dashboard(title, folder_uid,grafana_base_url, dashboard_json={}):
    """Creates a Grafana dashboard within a specified folder."""
    url = f"{grafana_base_url}/api/dashboards/db"
    default_dashboard_payload = {
        "dashboard": {
            "id": None,
            "uid": None,
            "title": title,
            "tags": ["script-created"],
            "timezone": "browser",
            "schemaVersion": 16,
            "version": 0,
            "graphTooltip": 0,
            "panels": [],
            "time": {"from": "now-6h", "to": "now"},
            "refresh": "5s"
        },
        "folderUid": folder_uid,
        "message": "Created by script"
    }
        # Merge custom dashboard_json if provided
    # Note: This is a shallow merge, for deep merge you might need more complex logic
    if dashboard_json:
        default_dashboard_payload["dashboard"].update(dashboard_json)

    try:
        response = requests.post(url, headers=HEADERS, json=default_dashboard_payload)
        response.raise_for_status()
        dashboard_data = response.json()
        print(f"Successfully created dashboard: {title} in folder UID: {folder_uid} (URL: {grafana_base_url}{dashboard_data['url']})")
        return dashboard_data
    except requests.exceptions.RequestException as e:
        print(f"Error creating dashboard '{title}': {e}")
        print(f"Response: {response.text if 'response' in locals() else 'N/A'}")
        return None

cli.add_command(get_dashboards)


if __name__ == '__main__':
   cli()