import requests
import os
import json

# Grafana Cloud Configuration
API_TOKEN = os.environ.get('GRAFANA_API_KEY', '')
GC_ACCESS_POLICY_TOKEN = os.environ.get('GC_AP_TOKEN', '') 

HEADERS = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json"
}

def create_data_source(ds_name,ds_type,ds_url,grafana_base_url,access_policy_user):
    # Data source configuration
    data_source_payload = {
        "name": ds_name,
        "type": ds_type,  # Change this to your data source type (e.g., elasticsearch, influxdb, etc.)
        "url": ds_url,  # Replace with your data source URL
        "access": "proxy",
        "basicAuth": True,
        "basicAuthUser": access_policy_user,
        "secureJsonData": {
        "basicAuthPassword": GC_ACCESS_POLICY_TOKEN
        }
        #GC_ACCESS_POLICY_TOKEN
      } 

    # API endpoint for creating a data source
    endpoint = f"{grafana_base_url}/api/datasources"

    # Send the POST request
    response = requests.post(endpoint, headers=HEADERS, data=json.dumps(data_source_payload))

    # Check the response
    if response.status_code == 200:
        print("Data source created successfully!")
        print(response.json())
        data = response.json()
        return data['datasource']['uid']
    else:
        print("Failed to create data source.")
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.text}")

def remove_data_source(ds_name,grafana_base_url):
    # API endpoint for creating a data source
    endpoint = f"{grafana_base_url}/api/datasources/name/{ds_name}"

    # Send the POST request
    response = requests.delete(endpoint, headers=HEADERS)

    # Check the response
    if response.status_code == 200:
        print("Data source deleted successfully!")
    else:
        print("Failed to delete data source.")


def add_data_source_permissions(team_id,data_source_uid,permission, grafana_base_url):
    # API endpoint for creating a data source permissions
    permissions_endpoint = f"/api/access-control/datasources/{data_source_uid}/teams/{team_id}"
    grafana_url = f"{grafana_base_url}{permissions_endpoint}"
    
    # Permissions payload
    permissions_payload = {
                "permission": permission  # Example for assigning Editor role to a team
    }

    # Make the POST request
    response = requests.post(grafana_url, json=permissions_payload, headers=HEADERS)

    # Check response
    if response.status_code == 200:
        print("Permissions updated successfully!")
    else:
        print(f"Failed to update permissions: {response.status_code}, {response.text}")