import requests
import click
import json
import os
import NestedFolder
import DataSource
import ldapManager
import CloudAccessPolicies
import yaml
from datetime import datetime


# Constant Variables
API_KEY = os.environ.get('GRAFANA_API_KEY', '')
ROLES = ["viewer","editor"]
ROLE_TO_ADD = "fixed:datasources:writer"
# Headers for authentication
HEADERS = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json"
}

@click.group()
def cli():
    """A command-line interface for team management."""
    pass

"""
 Function to add role to specific team
"""
def add_role_to_team(team_id, role_name,grafana_base_url):
    ADD_ROLE_TO_TEAM_URL_PREFIX = f"{grafana_base_url}/api/access-control/teams"
    """Adds a specified role to a team."""
    url = f"{ADD_ROLE_TO_TEAM_URL_PREFIX}/{team_id}/roles"
    payload = {
        "roles": [
            {
                "name": role_name,
                "global": True  # Fixed roles are typically global. For custom roles, adjust if scoped to an org.
            }
        ]
    }
    try:
        # Note: The Grafana API for assigning roles to a team might be a POST or PUT
        # to an endpoint that expects a list of roles to be assigned or updated.
        # This example assumes a PUT to update/add roles. Refer to the specific
        # Grafana Cloud RBAC API documentation for the exact payload and method.
        response = requests.put(url, headers=HEADERS, json=payload)
        response.raise_for_status()

        if response.status_code == 200:
            print(f"Successfully added role '{role_name}' to team with ID {team_id}.")
        else:
            print(f"Failed to add role. Status Code: {response.status_code}, Response: {response.text}")

    except requests.exceptions.RequestException as e:
        print(f"Error adding role to team: {e}")


def get_folder_uid(folder_title, grafana_base_url):
    url = f"{grafana_base_url}/api/folders?query={folder_title}"
    response = requests.get(url, headers=HEADERS)
    if response.status_code == 200:
        folders = response.json()
        print("Folder UID:", response.json())
        for folder in folders:
          if folder["title"] == folder_title:
             return folder["uid"]
    else:
        print("Failed to Fetch folder UID:", response.status_code, response.text)
        return  None

def get_team_id(team_name, grafana_base_url):
    url = f"{grafana_base_url}/api/teams/search"
    response = requests.get(url, headers=HEADERS)
    if response.status_code == 200:
        teams = response.json().get("teams", [])
        for team in teams:
            if team["name"] == team_name:
                return team["id"]
        print(f"Team '{team_name}' not found.")
        return None
    else:
        print(f"Failed to fetch teams. Status Code: {response.status_code}, Response: {response.text}")
        return None
    
def sync_external_group_to_team(team_name, external_group_id,grafana_base_url):
    team_id = get_team_id(team_name,grafana_base_url)
    if team_id:
        url = f"{grafana_base_url}/api/teams/{team_id}/groups"
        payload = {
            "GroupId": external_group_id
        }
        response = requests.post(url, headers=HEADERS, data=json.dumps(payload))
        if response.status_code == 200:
            print("External group successfully synced with Grafana team.")
        else:
            print(f"Failed to sync external group: {response.status_code}, {response.text}")
    else:
        print("Team Id not found!!!!")
   
# @click.command()
# @click.option('--team_name', required=True, help='Name of the team')
# @click.option('--email', required=True, help='Email of the team contact')
# @click.option('--grafana_base_url', required=True, help='Grafana Base URL')
# def create_team(team_name, email,grafana_base_url):
#     url = f"{grafana_base_url}/api/teams"
#     for role in ROLES:
#         payload = {
#             "name": team_name+'-'+role,
#             "email": email
#         }
#         response = requests.post(url, headers=HEADERS, data=json.dumps(payload))
#         if response.status_code == 200:
#             print("Team created successfully:", response.json())
#         else:
#             print("Failed to create team:", response.status_code, response.text)
#         data = response.json()
#         add_role_to_team(data.get("teamId"), ROLE_TO_ADD,grafana_base_url)
 
# @click.command()
# @click.option('--team_name', required=True, help='Name of the team')
# @click.option('--grafana_base_url', required=True, help='Grafana Base URL')
# def remove_team(team_name,grafana_base_url):
#     team_id = get_team_id(team_name,grafana_base_url)
#     url = f"{grafana_base_url}/api/teams/{team_id}"
#     response = requests.delete(url, headers=HEADERS)
#     if response.status_code == 200:
#         print(f"Team {team_name} with ID {team_id} deleted successfully.")
#     else:
#         print(f"Failed to delete team. Status Code: {response.status_code}, Response: {response.text}")


@click.command()
@click.option('--bu_name', required=True, help='Name of the Business Unit')
@click.option('--team_name', required=True, help='Name of the team')
@click.option('--environment', required=True, help='Environment')
@click.option('--grafana_base_url', required=True, help='Grafana Base URL')
def remove_team_complete_flow(bu_name,team_name,grafana_base_url,environment):
    # Base OU 
    BASE_OU = "OU=Devopsauthz,OU=Application Groups,OU=Regeneron Groups,DC=regeneron,DC=regn,DC=com"

    # Grafana URL for Teams Creation
    GRAFANA_URL = f"{grafana_base_url}/api/teams"
    
    # Grafana Data Source Types
    DATA_SOURCE_TYPES = ['prometheus','loki','tempo']
    
    ACCESS_POLICY_USER = {
        "prod" : "1210451",
        "dev"  : "1250760",
        "test" : "1292932"
    }
    lc_team_name = team_name.lower()
    lc_bu_name = bu_name.lower()  
    stack_id = ACCESS_POLICY_USER[environment]
    for role in ROLES:
        team_name_with_role = lc_team_name+'-'+role
        team_id = get_team_id(team_name_with_role, grafana_base_url)
        url = f"{grafana_base_url}/api/teams/{team_id}"
        response = requests.delete(url, headers=HEADERS)
        if response.status_code == 200:
            print(f"Team {team_name_with_role} with ID {team_id} deleted successfully.")
        else:
            print(f"Failed to delete team. Status Code: {response.status_code}, Response: {response.text}")

    CloudAccessPolicies.delete_access_policy(lc_team_name)

    folder_uid = NestedFolder.get_folder_uid(grafana_base_url,stack_id,lc_team_name,lc_bu_name)
    NestedFolder.remove_folder(folder_uid,stack_id,grafana_base_url)

    for ds_type in DATA_SOURCE_TYPES:
        data_source_name = f"{lc_team_name}-regeneron-{environment}-{ds_type}"
        DataSource.remove_data_source(data_source_name,grafana_base_url)

def global_variables(grafana_base_url):
    # Base OU 
    global BASE_OU , GRAFANA_URL , DATA_SOURCE_TYPES ,  DATA_SOURCE_URLS, PARENT_GROUP_IDS, ACCESS_POLICY_USER, PERMISSION_IDS
    BASE_OU = "OU=Devopsauthz,OU=Application Groups,OU=Regeneron Groups,DC=regeneron,DC=regn,DC=com"
    # Grafana URL for Teams Creation
    GRAFANA_URL = f"{grafana_base_url}/api/teams"
    
    # Grafana Data Source Types
    DATA_SOURCE_TYPES = ['prometheus','loki','tempo']
    
    # Grafana Data Source URLs
    DATA_SOURCE_URLS = {"prometheus":'https://prometheus-prod-56-prod-us-east-2.grafana.net/api/prom',
                      "loki":'https://insight-logs-prod-us-east-2.grafana.net',
                      "tempo": 'https://tempo-prod-26-prod-us-east-2.grafana.net/tempo'}
    
    # AD Group ID for assigning Teams Group IDs
    PARENT_GROUP_IDS = {
        "prod" : "Group_Okta_App_Grafana_SaaS_Prod",
        "dev"  : "Group_Okta_App_Grafana_SaaS_Dev",
        "test" : "Group_Okta_App_Grafana_SaaS_Test"
    }
    ACCESS_POLICY_USER = {
        "prod" : "1210451",
        "dev"  : "1250760",
        "test" : "1292932"
    }
    PERMISSION_IDS = {
        "editor" : "2",
        "viewer" : "1"
    }

def setup_team_folder_ldap_permssions(environment,folder_name,team_name,bu_name,grafana_base_url,owner_email):
        stack_id = ACCESS_POLICY_USER[environment]
        lc_team_name = team_name.lower()
        dic = folder_name.split("/")
        if len(dic)>1:
           local_bu_name = dic[0]
           local_folder_name = dic[1]
        else:
            local_bu_name = bu_name
            local_folder_name = dic[0]

        folder_uid=NestedFolder.nested_folder(local_bu_name,stack_id,local_folder_name,grafana_base_url)

        for role in ROLES:
            team_name_with_role = lc_team_name+'-'+role
            payload = {
                "name": team_name_with_role,
                "email": owner_email
            }
            response = requests.post(GRAFANA_URL, headers=HEADERS, data=json.dumps(payload))
            if response.status_code == 200:
                print("Team created successfully:", response.json())
            else:
                print("Failed to create team:", response.status_code, response.text)

            data = response.json()
            team_id = data['teamId']
            permission_id = PERMISSION_IDS[role]
            NestedFolder.set_folder_permission_for_team(permission_id,int(team_id),folder_uid,grafana_base_url)

            ad_group_name = f"grafana-saas-{environment}-{lc_team_name}-{role}"
            description =  f"grafana saas {environment} {lc_team_name} {role}"
            parent_group_id=PARENT_GROUP_IDS[environment]

            # Create AD Group -Editor & Viewer
            ldapManager.create_group_in_ou(group_name=ad_group_name,ou=BASE_OU,description=description)

            #Add AD group to Parent Group - Prod, Dev, & Test
            ldapManager.add_user_to_group(ad_group_name,parent_group_id, 'group')

            # Sync AD Groups to Teams
            sync_external_group_to_team(team_name_with_role,ad_group_name,grafana_base_url)

def setup_data_source(team_name,environment,grafana_base_url,stack_id):
    lc_team_name = team_name.lower()
    for data_source_type in DATA_SOURCE_TYPES:
            data_source_name = f"{lc_team_name}-regeneron-{environment}-{data_source_type}"  

            data_source_url = DATA_SOURCE_URLS[data_source_type]
            
            data_source_uid = DataSource.create_data_source(data_source_name,data_source_type,data_source_url,grafana_base_url,stack_id)
            for role in ROLES:
                if role == "viewer":
                    data_source_team_permission = "Query"
                    
                elif role == "editor":
                    data_source_team_permission = "Edit"

                team_name_with_role = lc_team_name+'-'+role
                team_id = get_team_id(team_name_with_role,grafana_base_url)  
                DataSource.add_data_source_permissions(team_id,data_source_uid,data_source_team_permission,grafana_base_url)

def get_initial_new_team_data(snow_id,bu_name,team_name,owner_email,environment):
    new_team_data = {}
    new_team_data[snow_id] = {
        "requested_date": datetime.now(),
        "owner": f'{owner_email}',
        "bu_name": bu_name,
        "team_name": team_name,
        "environment": environment,
        "team_id": [],
        "ad_groups": [],
        "data_source": '',
        "access_policies":{},
        "dashboard_folder":'',
        "is_provisioned": 'no',
        'provisioned_date': '' 
         }
    return new_team_data

@click.command()
@click.option('--snow_id', help='Service Now Ticket Number')
@click.option('--bu_name', required=True, help='Name of the Business Unit')
@click.option('--team_name', required=True, help='Name of the team')
@click.option('--owner_email', required=True, help='Email of the team contact')
@click.option('--grafana_base_url', required=True, help='Grafana Base URL')
@click.option('--folder_name', required=True, help='folder name')
@click.option('--lbac_details', required=True, help='lbac details')
@click.option('--invoke_type', required=True, help='Invoke type can be "FromConfig" or "FromServiceNow" or "FromJenkinsJob"')
@click.option('--environment', required=True, help='Environment')
def create_team(snow_id,bu_name, team_name,owner_email,grafana_base_url,folder_name,lbac_details,environment,invoke_type):
    # Invoke type can be "FromConfig" or "FromServiceNow" or "FromJenkinsJob"
    # Global Variable 
    global_variables(grafana_base_url)  
    env = environment.lower()
    stack_id = ACCESS_POLICY_USER[env]
    update_team_data = {
        "team_id": [],
        "ad_groups": [],
        "data_source": '',
        "access_policies":{},
        "dashboard_folder":'',
    }
    try:
        # setup_team_folder_ldap_permssions(env,folder_name,team_name,bu_name,grafana_base_url,owner_email)
 
        # CloudAccessPolicies.create_grafana_saas_access_policy(team_name,ACCESS_POLICY_USER[env],lbac_details)

        # setup_data_source(team_name,env,grafana_base_url,stack_id)

        if invoke_type == "FromServiceNow":
            file_path = f'/home/jenkins/agent/workspace/grafana-saas/grafana-saas-automation/Service-Now-Requests/observability-platform-access-database/{environment.lower()}/Teams.yaml'
            new_team_data= get_initial_new_team_data(snow_id,bu_name.lower(),team_name.lower(),owner_email.lower(),environment.lower())
            for role in ROLES:
              ad_group_name = 'grafana-saas-'+environment+'-'+bu_name.lower()+'-'+team_name.lower()+'-'+role
              team_name_with_role = bu_name.lower()+'-'+team_name.lower()+'-'+role
              new_team_data[snow_id]['ad_groups'].append(ad_group_name)   
              new_team_data[snow_id]['team_id'].append(team_name_with_role)
              
            with open(file_path,'r') as file:
                data = yaml.safe_load(file)
                data.update(new_team_data)
                
            with open(file_path,'w') as file:
                    yaml.dump(data,file,sort_keys=False)
        elif invoke_type == "FromConfig":
            for role in ROLES:
              ad_group_name = 'grafana-saas-'+environment+'-'+bu_name.lower()+'-'+team_name.lower()+'-'+role
              team_name_with_role = bu_name.lower()+'-'+team_name.lower()+'-'+role
              update_team_data[snow_id]['ad_groups'].append(ad_group_name)   
              update_team_data[snow_id]['team_id'].append(team_name_with_role)
            return  update_team_data
            
    except requests.exceptions.RequestException as e:
        print(f"Error creating team'{team_name}': {e}")

def create_team_from_config(environment,grafana_base_url):

    file_path = f'/home/jenkins/agent/workspace/grafana-saas/grafana-saas-automation/Team-Permissions/observability-platform-access-database/{environment.lower()}/Teams.yaml'
    with open(file_path,'r') as file:
         data = yaml.safe_load(file)
         for i in data:
            if data[i]['is_provisioned'] == 'no':
               print(grafana_base_url)
               print(data[i])
               updated_data = create_team(data[i],data[i]['bu_name'], data[i]['team_name'], data[i]['owner'], grafana_base_url,data[i]['folder_name'],data[i]['lbac_details'],data[i]['environment'],'FromConfig')
               data[i]['is_provisioned'] ='yes'
               data[i]['provisioned_date'] = datetime.now()
               data[i]['team_id'] = updated_data['team_id']
               data[i]['ad_groups'] = updated_data['ad_groups']
            
         with open(file_path,'w') as file:
             yaml.dump(data,file,sort_keys=False)

# def create_team_from_config(bu_name, team_name, owner_email,environment,grafana_base_url):
#     # Base OU 
#     BASE_OU = "OU=Devopsauthz,OU=Application Groups,OU=Regeneron Groups,DC=regeneron,DC=regn,DC=com"

#     # Grafana URL for Teams Creation
#     GRAFANA_URL = f"{grafana_base_url}/api/teams"
    
#     # Grafana Data Source Types
#     DATA_SOURCE_TYPES = ['prometheus','loki','tempo']
    
#     # Grafana Data Source URLs
#     DATA_SOURCE_URLS = {"prometheus":'https://prometheus-prod-56-prod-us-east-2.grafana.net/api/prom',
#                       "loki":'https://insight-logs-prod-us-east-2.grafana.net',
#                       "tempo": 'https://tempo-prod-26-prod-us-east-2.grafana.net/tempo'}
    
#     # AD Group ID for assigning Teams Group IDs
#     PARENT_GROUP_IDS = {
#         "prod" : "Group_Okta_App_Grafana_SaaS_Prod",
#         "dev"  : "Group_Okta_App_Grafana_SaaS_Dev",
#         "test" : "Group_Okta_App_Grafana_SaaS_Test"
#     }
#     ACCESS_POLICY_USER = {
#         "prod" : "1210451",
#         "dev"  : "1250760",
#         "test" : "1292932"
#     }
#     PERMISSION_IDS = {
#         "editor" : "2",
#         "viewer" : "1"
#     }
#     new_team_data = {
#         "team_id": [],
#         "ad_groups": [],
#         "data_source": '',
#         "access_policies":{},
#         "dashboard_folder":'',
#         }
#     lc_team_name = team_name.lower()
#     lc_bu_name = bu_name.lower()               
#     try:
#         stack_id = ACCESS_POLICY_USER[environment]
#         folder_uid=NestedFolder.nested_folder(bu_name,stack_id,team_name,grafana_base_url)

#         for role in ROLES:
#             team_name_with_role = lc_team_name+'-'+role
#             payload = {
#                 "name": team_name_with_role,
#                 "email": owner_email
#             }
#             response = requests.post(GRAFANA_URL, headers=HEADERS, data=json.dumps(payload))
#             if response.status_code == 200:
#                 print("Team created successfully:", response.json())
#             else:
#                 print("Failed to create team:", response.status_code, response.text)

#             data = response.json()
#             team_id = data['teamId']
#             new_team_data['team_id'].append(team_id)
#             permission_id = PERMISSION_IDS[role]
#             NestedFolder.set_folder_permission_for_team(permission_id,int(team_id),folder_uid,grafana_base_url)

#             ad_group_name = f"grafana-saas-{environment}-{lc_team_name}-{role}"
#             description =  f"grafana saas {environment} {lc_team_name} {role}"
#             parent_group_id=PARENT_GROUP_IDS[environment]
#             new_team_data['ad_groups'].append(ad_group_name)
#             # Create AD Group -Editor & Viewer
#             ldapManager.create_group_in_ou(group_name=ad_group_name,ou=BASE_OU,description=description)

#             #Add AD group to Parent Group - Prod, Dev, & Test
#             ldapManager.add_user_to_group(ad_group_name,parent_group_id, 'group')

#             # Sync AD Groups to Teams
#             sync_external_group_to_team(team_name_with_role,ad_group_name,grafana_base_url)
        
#         CloudAccessPolicies.create_grafana_saas_access_policy(lc_team_name,ACCESS_POLICY_USER[environment])


#         for data_source_type in DATA_SOURCE_TYPES:
#             data_source_name = f"{lc_team_name}-regeneron-{environment}-{data_source_type}"  

#             data_source_url = DATA_SOURCE_URLS[data_source_type]
            
#             data_source_uid = DataSource.create_data_source(data_source_name,data_source_type,data_source_url,grafana_base_url,'2510099')
#             for role in ROLES:
#                 if role == "viewer":
#                     data_source_team_permission = "Query"
                    
#                 elif role == "editor":
#                     data_source_team_permission = "Edit"

#                 team_name_with_role = lc_team_name+'-'+role
#                 team_id = get_team_id(team_name_with_role,grafana_base_url)  
#                 DataSource.add_data_source_permissions(team_id,data_source_uid,data_source_team_permission,grafana_base_url)
#         return new_team_data
#     except requests.exceptions.RequestException as e:
#         print(f"Error creating team'{team_name_with_role}': {e}")

# def create_team_snow_request(snow_id,bu_name, team_name, owner_email,environment,grafana_base_url,new_team_data):
#     # Base OU 
#     BASE_OU = "OU=Devopsauthz,OU=Application Groups,OU=Regeneron Groups,DC=regeneron,DC=regn,DC=com"

#     # Grafana URL for Teams Creation
#     GRAFANA_URL = f"{grafana_base_url}/api/teams"
    
#     # Grafana Data Source Types
#     DATA_SOURCE_TYPES = ['prometheus','loki','tempo']
    
#     # Grafana Data Source URLs
#     DATA_SOURCE_URLS = {"prometheus":'https://prometheus-prod-56-prod-us-east-2.grafana.net/api/prom',
#                       "loki":'https://insight-logs-prod-us-east-2.grafana.net',
#                       "tempo": 'https://tempo-prod-26-prod-us-east-2.grafana.net/tempo'}
    
#     # AD Group ID for assigning Teams Group IDs
#     PARENT_GROUP_IDS = {
#         "prod" : "Group_Okta_App_Grafana_SaaS_Prod",
#         "dev"  : "Group_Okta_App_Grafana_SaaS_Dev",
#         "test" : "Group_Okta_App_Grafana_SaaS_Test"
#     }
#     ACCESS_POLICY_USER = {
#         "prod" : "1210451",
#         "dev"  : "1250760",
#         "test" : "1292932"
#     }
#     PERMISSION_IDS = {
#         "editor" : "2",
#         "viewer" : "1"
#     }
#     lc_team_name = team_name.lower()
#     lc_bu_name = bu_name.lower()                
#     try:
#         stack_id = ACCESS_POLICY_USER[environment]
#         folder_uid=NestedFolder.nested_folder(bu_name,stack_id,team_name,grafana_base_url)

#         for role in ROLES:
#             team_name_with_role = lc_team_name+'-'+role
#             payload = {
#                 "name": team_name_with_role,
#                 "email": owner_email
#             }
#             response = requests.post(GRAFANA_URL, headers=HEADERS, data=json.dumps(payload))
#             if response.status_code == 200:
#                 print("Team created successfully:", response.json())
#             else:
#                 print("Failed to create team:", response.status_code, response.text)

#             data = response.json()
#             team_id = data['teamId']
#             new_team_data[snow_id]['team_id'].append(team_id)
#             permission_id = PERMISSION_IDS[role]
#             NestedFolder.set_folder_permission_for_team(permission_id,int(team_id),folder_uid,grafana_base_url)

#             ad_group_name = f"grafana-saas-{environment}-{lc_team_name}-{role}"
#             description =  f"grafana saas {environment} {lc_team_name} {role}"
#             parent_group_id=PARENT_GROUP_IDS[environment]

#             # Create AD Group -Editor & Viewer
#             ldapManager.create_group_in_ou(group_name=ad_group_name,ou=BASE_OU,description=description)

#             #Add AD group to Parent Group - Prod, Dev, & Test
#             ldapManager.add_user_to_group(ad_group_name,parent_group_id, 'group')
#             new_team_data[snow_id]['ad_groups'].append(ad_group_name)
#             # Sync AD Groups to Teams
#             sync_external_group_to_team(team_name_with_role,ad_group_name,grafana_base_url)
        
#         CloudAccessPolicies.create_grafana_saas_access_policy(lc_team_name,ACCESS_POLICY_USER[environment])


#         for data_source_type in DATA_SOURCE_TYPES:
#             data_source_name = f"{lc_team_name}-regeneron-{environment}-{data_source_type}"  

#             data_source_url = DATA_SOURCE_URLS[data_source_type]
            
#             data_source_uid = DataSource.create_data_source(data_source_name,data_source_type,data_source_url,grafana_base_url,'2510099')
#             for role in ROLES:
#                 if role == "viewer":
#                     data_source_team_permission = "Query"
                    
#                 elif role == "editor":
#                     data_source_team_permission = "Edit"

#                 team_name_with_role = lc_team_name+'-'+role
#                 team_id = get_team_id(team_name_with_role,grafana_base_url)  
#                 DataSource.add_data_source_permissions(team_id,data_source_uid,data_source_team_permission,grafana_base_url)
#         new_team_data[snow_id]['is_provisioned'] ='yes'
#         new_team_data[snow_id]['provisioned_date'] = datetime.now()    
#         return new_team_data
#     except requests.exceptions.RequestException as e:
#         print(f"Error creating team'{team_name_with_role}': {e}")
        
cli.add_command(create_team)
# cli.add_command(remove_team)


if __name__ == '__main__':
    cli()
