import ldapManager
import yaml
from datetime import datetime
import ldapManager
import os
import subprocess

def get_initial_access_data(snow_id,access_type,bu_name,team_name,environment,role,user):
    access_data = {}
    access_data[snow_id] = {
        "requested_date": datetime.now(),
        "bu_name": str(bu_name),
        "team_name": str(team_name),
        "environment": str(environment),
        "role": str(role),
        "user": str(user),
        "request_type": str(access_type),
        "is_provisioned": 'no',
        "provisioned_date": ''
         }
    return access_data


def provide_access_snow_request(snow_id, access_type, bu_name, team_name, environment, role, user):
    file_path = f'/home/jenkins/agent/workspace/grafana-saas/grafana-saas-automation/service-now-requests/observability-platform-access-database/{environment.lower()}/UserAccess.yaml'
    new_access_data = get_initial_access_data(snow_id, access_type.lower(), bu_name.lower(), team_name.lower(), environment.lower(), role.lower(), user.lower())
    provide_access(bu_name, team_name, environment, role, user)
    new_access_data[snow_id]['is_provisioned'] ='yes'
    new_access_data[snow_id]['provisioned_date'] = datetime.now()
    with open(file_path, 'r') as file:
        data = yaml.safe_load(file)
        data.update(new_access_data)

        with open(file_path, 'w') as file:
            yaml.dump(data, file, sort_keys=False)

def provide_access_from_config(environment):
    file_path = f'/home/jenkins/agent/workspace/grafana-saas/grafana-saas-automation/service-now-requests/observability-platform-access-database/{environment.lower()}/UserAccess.yaml'
    print("testing") 
    with open(file_path, 'r') as file:
        data = yaml.safe_load(file)
        for i in data:
            if data[i]['is_provisioned'] == 'no' and data[i]['request_type'] == 'provide_access':
               provide_access(data[i]['bu_name'], data[i]['team_name'], data[i]['environment'], data[i]['role'], data[i]['user'])
               data[i]['is_provisioned'] ='yes'
               data[i]['provisioned_date'] = datetime.now()
        with open(file_path, 'w') as file:
            yaml.dump(data, file, sort_keys=False)

def provide_access(bu_name,team_name,environment,role,user):
    lc_bu_name = bu_name.lower()
    lc_team_name = team_name.lower()
    lc_environment = environment.lower()
    lc_role = role.lower()
    lc_user = user.lower()
    group_name = f'grafana_saas_{lc_environment}_{lc_team_name}_{lc_role}'
    ldapManager.add_user_to_group(user,group_name)


def remove_access_snow_request(snow_id, access_type, bu_name, team_name, environment, role, user):
    file_path = f'/home/jenkins/agent/workspace/grafana-saas/grafana-saas-automation/service-now-requests/observability-platform-access-database/{environment.lower()}/UserAccess.yaml'
    new_access_data = get_initial_access_data(snow_id, access_type.lower(), bu_name.lower(), team_name.lower(), environment.lower(), role.lower(), user.lower())
    remove_access(bu_name, team_name, environment, role, user)
    new_access_data[snow_id]['is_provisioned'] ='yes'
    new_access_data[snow_id]['provisioned_date'] = datetime.now()
    with open(file_path, 'r') as file:
        data = yaml.safe_load(file)
        data.update(new_access_data)

        with open(file_path, 'w') as file:
            yaml.dump(data, file, sort_keys=False)

def remove_access_from_config(environment):
    file_path = f'/home/jenkins/agent/workspace/grafana-saas/grafana-saas-automation/service-now-requests/observability-platform-access-database/{environment.lower()}/UserAccess.yaml'
    with open(file_path, 'r') as file:
        data = yaml.safe_load(file)
        for i in data:
            if data[i]['is_provisioned'] == 'no' and data[i]['request_type'] == 'remove_access':
               remove_access(data[i]['bu_name'], data[i]['team_name'], data[i]['environment'], data[i]['role'], data[i]['user'])
               data[i]['is_provisioned'] ='yes'
               data[i]['provisioned_date'] = datetime.now()
        with open(file_path, 'w') as file:
            yaml.dump(data, file, sort_keys=False)

def remove_access(bu_name,team_name,environment,role,user):
    lc_bu_name = bu_name.lower()
    lc_team_name = team_name.lower()
    lc_environment = environment.lower()
    lc_role = role.lower()
    lc_user = user.lower()
    group_name = f'grafana_saas_{lc_environment}_{lc_team_name}_{lc_role}'
    ldapManager.remove_user_from_group(user,group_name)
