import ldapManager
import yaml
import Team
from datetime import datetime

def create_team_from_config(environment):
    print("new Team from config")
    print("test")
    file_path = f'/home/jenkins/agent/workspace/grafana-saas/grafana-saas-automation/service-now-requests/observability-platform-access-database/{environment.lower()}/Teams.yaml'
    url = {
        "prod": "https://regeneron.grafana.net",
        "dev": "https://regenerondev.grafana.net",
        "test": "https://regenerontest.grafana.net"
    }

    with open(file_path,'r') as file:
         data = yaml.safe_load(file)
         for i in data:
            if data[i]['is_provisioned'] == 'no':
               env = data[i]['environment'].lower()
               grafana_base_url=url[env]
               print(grafana_base_url)
               print(data[i])
               update_data = Team.create_team_from_config_complete_flow(data[i]['bu_name'], data[i]['team_name'], data[i]['owner'], data[i]['environment'], grafana_base_url)
               data[i]['is_provisioned'] ='yes'
               data[i]['provisioned_date'] = datetime.now()
               data[i]['team_id'] = update_data['team_id']
               data[i]['ad_groups'] = update_data['ad_groups']
            
         with open(file_path,'w') as file:
             yaml.dump(data,file,sort_keys=False)