def ldapOUMappings = [
    'ldap-manager-password-devopsauthz': 'CN=svc.devops-authz-mgr,OU=System,OU=Regeneron Accounts,DC=regeneron,DC=regn,DC=com'
]
pipeline {
    agent { label 'cli-tools'}
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
    }
    environment {
        LDAP_HOST = "ldaps://regn-ldaps.regeneron.com"
        LDAP_PORT = 636
        CREDENTIALS_ID = "ldap-manager-password-devopsauthz"
        BASE_RAD_OU = "OU=Devopsauthz,OU=Application Groups,OU=Regeneron Groups,DC=regeneron,DC=regn,DC=com"
    }
    parameters {
        string(name: 'EXTERNAL_GROUP_ID', defaultValue: '', description: 'Name of External Group ID')
        string(name: 'TEAM_NAME', defaultValue: '', description: 'Name of Team to Sync with external Group ID')
        choice(name: 'ENVIRONMENT', choices:['Dev','Test','Prod'], description: 'Select Environment either Prod or NonProd')
    }
    
    
    stages {
        stage('Create Nested Folder') {
            steps { script {
                def ldapCredentailsId = 'ldap-manager-password-devopsauthz'
                println("Adding Nested Folder: ${params.TEAM_NAME}") 
                // Initialize credentialsId variable
                def credentialsId
                if (params.ENVIRONMENT =='prod') {
                    GRAFANA_BASE_URL = "https://regeneron.grafana.net"
                    credentialsId = 'grafana-saas-prod-platform-api-key'
                }
                else if (params.ENVIRONMENT =='dev') {
                    GRAFANA_BASE_URL = "https://regenerondev.grafana.net"
                    credentialsId = 'grafana-saas-dev-platform-api-key'
                }
                else if (params.ENVIRONMENT =='test') {
                    GRAFANA_BASE_URL = "https://regenerontest.grafana.net"
                    credentialsId = 'grafana-saas-test-platform-api-key'
                }     
                    withCredentials([string(credentialsId: credentialsId, variable: 'GRAFANA_API_KEY'),string(credentialsId: ldapCredentailsId, variable: 'BINDING_PW')]) {
                        def binding_dn = ldapOUMappings[ldapCredentailsId]
                        //Grafana API settings
                        sh """
                           export "BINDING_DN=${binding_dn}"
                           python modules/GrafanaAutomation.py ga-sync-external-group-to-team --team_name '${params.TEAM_NAME}' --external_group_id '${params.EXTERNAL_GROUP_ID}' --grafana_base_url '${GRAFANA_BASE_URL}'
                        """
                    }
               }
            }
        }

    }
}