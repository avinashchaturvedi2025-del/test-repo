def ldapOUMappings = [
    'ldap-manager-password-devopsauthz': 'CN=svc.devops-authz-mgr,OU=System,OU=Regeneron Accounts,DC=regeneron,DC=regn,DC=com'
]
pipeline {
    agent { label 'cli-tools'}
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
    }
    environment {
        LDAP_HOST = "ldaps://regn-ldaps.regeneron.com"
        LDAP_PORT = 636
        CREDENTIALS_ID = "ldap-manager-password-devopsauthz"
        BASE_RAD_OU = "OU=Devopsauthz,OU=Application Groups,OU=Regeneron Groups,DC=regeneron,DC=regn,DC=com"
        // Define the URL of the repository you want to clone and modify
        BITBUCKET_REPO_URL = 'ssh://git@ritscm.regeneron.com/iteso/observability-platform-access-database.git'
        // Use the ID of the credentials you stored in Jenkins
        BITBUCKET_CREDENTIALS_ID = 'bitbucket-publish'
    }
    parameters {
        // string(name: 'SNOW_ID', defaultValue: '', description: 'Service Now Ticket ID')
        // string(name: 'BU_NAME', defaultValue: '', description: 'Name of Business Unit of Specific team')
        // string(name: 'TEAM_NAME', defaultValue: '', description: 'Name of Team to add to Grafana SaaS, must beging with (ites|rit)-')
        // string(name: 'DESCRIPTION', defaultValue: '', description: 'Description of Team')
        choice(name: 'ENVIRONMENT', choices:['Dev','Test','Prod'], description: 'Select Environment either Prod or Dev or Test')
    }
    
    
    stages {
        stage('Clone Observability Access Database Repository') {
            steps {
                script {
                  sshagent (credentials:['bitbucket-publish']) { 
                    sh """
                        cd ..
                        git clone ssh://git@ritscm.regeneron.com/iteso/observability-platform-access-database.git
                    """  
                  }
                }
            }    
         }
        stage('Create Team') {
            steps { script {
                println("Adding New Team: ${params.TEAM_NAME}") 
                // Initialize credentialsId variable
                def credentialsId
                
                // Determine credentialsId based on environment
                if (params.ENVIRONMENT =='Prod') {
                    GRAFANA_BASE_URL = "https://regeneron.grafana.net"
                    credentialsId = 'grafana-saas-prod-platform-api-key'
                }
                else if (params.ENVIRONMENT =='Dev') {
                    GRAFANA_BASE_URL = "https://regenerondev.grafana.net"
                    credentialsId = 'grafana-saas-dev-platform-api-key'
                }
                else if (params.ENVIRONMENT =='Test') {
                    GRAFANA_BASE_URL = "https://regenerontest.grafana.net"
                    credentialsId = 'grafana-saas-test-platform-api-key'
                }
                def ldapcredentialsId = 'ldap-manager-password-devopsauthz' 
                def gcaptcredentialsId='grafana-cloud-access-policy-token' 
                
                    withCredentials([string(credentialsId: credentialsId, variable: 'GRAFANA_API_KEY'), string(credentialsId: ldapcredentialsId, variable: 'BINDING_PW'), string(credentialsId: gcaptcredentialsId, variable: 'GC_AP_TOKEN')]) {
                        def binding_dn = ldapOUMappings[ldapcredentialsId]
                        //Grafana API settings
                        sh """
                           export "BINDING_DN=${binding_dn}"
                           python modules/GrafanaAutomation.py ga-create-team-from-config  --environment '${params.ENVIRONMENT}' --grafana_base_url  GRAFANA_BASE_URL
                        """
                    }
               }
            }
        }

        stage('Commit and Push') {
            steps {
                script {
                        sshagent (credentials:['bitbucket-publish']) {
                        withCredentials([sshUserPrivateKey(credentialsId: 'bitbucket-publish',
                            usernameVariable: 'SSH_USER_NAME',
                            keyFileVariable: 'SSH_KEY')]) {
                        sh """
                           cd ..
                           cd observability-platform-access-database
                           echo `date`>> fileupdate.txt
                           git config user.email '${SSH_USER_NAME}@regeneron.com' 
                           git config user.name ${SSH_USER_NAME}
                           git add .
                           git commit -m "feat: UserAccess.yaml file updated via Jenkins pipeline"
                           git push origin master
                        """
                        }
                   }
                }
            }
        } 
    }
}