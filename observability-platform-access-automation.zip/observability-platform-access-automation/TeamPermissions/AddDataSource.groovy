def ldapOUMappings = [
    'ldap-manager-password-devopsauthz': 'CN=svc.devops-authz-mgr,OU=System,OU=Regeneron Accounts,DC=regeneron,DC=regn,DC=com'
]
pipeline {
    agent { label 'cli-tools'}
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
    }
    environment {
        LDAP_HOST = "ldaps://regn-ldaps.regeneron.com"
        LDAP_PORT = 636
        CREDENTIALS_ID = "ldap-manager-password-devopsauthz"
        BASE_RAD_OU = "OU=Devopsauthz,OU=Application Groups,OU=Regeneron Groups,DC=regeneron,DC=regn,DC=com"
    }
    parameters {
        string(name: 'DATA_SOURCE_NAME', defaultValue: '', description: 'Data Source Name of Business Unit of Specific team')
        string(name: 'DATA_SOURCE_TYPE', defaultValue: '', description: 'Data Source Type')
        string(name: 'DATA_SOURCE_URL', defaultValue: '', description: 'Data Source URL')
        choice(name: 'ENVIRONMENT', choices:['dev','test','prod'], description: 'Select Environment either Prod or Dev or Test')     
    }
    
    
    stages {
        stage('Create Data Source') {
            steps { script {
                println("Adding Nested Folder: ${params.FOLDER_NAME}") 
                // Initialize credentialsId variable
                def credentialsId
                if (params.ENVIRONMENT =='prod') {
                    GRAFANA_BASE_URL = "https://regeneron.grafana.net"
                    credentialsId = 'grafana-saas-prod-platform-api-key'
                    access_policy_user ='1210451'
                }
                else if (params.ENVIRONMENT =='dev') {
                    GRAFANA_BASE_URL = "https://regenerondev.grafana.net"
                    credentialsId = 'grafana-saas-dev-platform-api-key'
                    access_policy_user ='1250760'
                }
                else if (params.ENVIRONMENT =='test') {
                    GRAFANA_BASE_URL = "https://regenerontest.grafana.net"
                    credentialsId = 'grafana-saas-test-platform-api-key'
                    access_policy_user ='1292932'
                }                
                    withCredentials([string(credentialsId: credentialsId, variable: 'GRAFANA_API_KEY')]) {
                        //Grafana API settings
                        sh """
                           python modules/GrafanaAutomation.py  ga-create-data-source --ds_name ${DATA_SOURCE_NAME} --ds_type ${DATA_SOURCE_TYPE} --ds_url ${DATA_SOURCE_URL} --grafana_base_url ${GRAFANA_BASE_URL} --access_policy_user ${access_policy_user}
                        """
                    }
               }
            }
        }

    }
}