def ldapOUMappings = [
    'ldap-manager-password-devopsauthz': 'CN=svc.devops-authz-mgr,OU=System,OU=Regeneron Accounts,DC=regeneron,DC=regn,DC=com'
]
pipeline {
    agent { label 'cli-tools'}
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
    }
    environment {
        LDAP_HOST = "ldaps://regn-ldaps.regeneron.com"
        LDAP_PORT = 636
        CREDENTIALS_ID = "ldap-manager-password-devopsauthz"
        BASE_RAD_OU = "OU=Devopsauthz,OU=Application Groups,OU=Regeneron Groups,DC=regeneron,DC=regn,DC=com"
    }
    parameters {
        string(name: 'BU_NAME', defaultValue: '', description: 'Name of Business Unit of Specific team')
        string(name: 'TEAM_NAME', defaultValue: '', description: 'Name of Team to add to Grafana SaaS, must beging with (ites|rit)-')
        string(name: 'DESCRIPTION', defaultValue: '', description: 'Description of Team')
        string(name: 'FOLDER_NAME', defaultValue: '',  description: 'Indicates the folder need to be created for this team, ex: IOPS-EDMS, note if you provide / then the folder will be nested ex /Infra/Database will create Database folder with parent as Infra. If you do not provide a parent folder, Business Unit will be used as the default folder.')
        string(name: 'LBAC_DETAILS', defaultValue: '', description: 'LBAC Lables can be multiple key pair values as Dictionary')
        choice(name: 'ENVIRONMENT', choices:['Dev','Test','Prod'], description: 'Select Environment either Prod or Dev or Test')
        string(name: 'OWNER_EMAIL',defaultValue: '', description: 'Owner Email')
    }
    
    
    stages {
        stage('Create Team') {
            steps { script {
                // Initialize credentialsId variable
                def credentialsId
                // Determine credentialsId based on environment
                if (params.ENVIRONMENT =='Prod') {
                    GRAFANA_BASE_URL = "https://regeneron.grafana.net"
                    credentialsId = 'grafana-saas-prod-platform-api-key'
                }
                else if (params.ENVIRONMENT =='Dev') {
                    GRAFANA_BASE_URL = "https://regenerondev.grafana.net"
                    credentialsId = 'grafana-saas-dev-platform-api-key'
                }
                else if (params.ENVIRONMENT =='Test') {
                    GRAFANA_BASE_URL = "https://regenerontest.grafana.net"
                    credentialsId = 'grafana-saas-test-platform-api-key'
                }
                def ldapcredentialsId = 'ldap-manager-password-devopsauthz' 
                def gcaptcredentialsId='grafana-cloud-access-policy-token' 
                
                    withCredentials([string(credentialsId: credentialsId, variable: 'GRAFANA_API_KEY'), string(credentialsId: ldapcredentialsId, variable: 'BINDING_PW'), string(credentialsId: gcaptcredentialsId, variable: 'GC_AP_TOKEN')]) {
                        def binding_dn = ldapOUMappings[ldapcredentialsId]
                        //Grafana API settings
                        sh """
                           export "BINDING_DN=${binding_dn}"
                           python modules/Team.py create-team --bu_name '${params.BU_NAME}' --team_name '${params.TEAM_NAME}' --owner_email '${params.OWNER_EMAIL}' --grafana_base_url '${GRAFANA_BASE_URL}' --folder_name '${params.FOLDER_NAME}' --lbac_details '${params.LBAC_DETAILS}' --environment '${environment}' --invoke_type 'FromJenkinsJob'
                       
                        """
                    }
               }
            }
        }
    }
}