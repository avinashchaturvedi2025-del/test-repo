def ldapOUMappings = [
    'ldap-manager-password-devopsauthz': 'CN=svc.devops-authz-mgr,OU=System,OU=Regeneron Accounts,DC=regeneron,DC=regn,DC=com'
]
pipeline {
    agent { label 'cli-tools'}
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
    }
    environment {
        LDAP_HOST = "ldaps://regn-ldaps.regeneron.com"
        LDAP_PORT = 636
        CREDENTIALS_ID = "ldap-manager-password-devopsauthz"
        BASE_RAD_OU = "OU=Devopsauthz,OU=Application Groups,OU=Regeneron Groups,DC=regeneron,DC=regn,DC=com"
    }
    parameters {
        choice(name: 'ENVIRONMENT', choices:['Dev','Test','Prod'], description: 'Select Environment either Prod or NonProd')     
    }
    
    
    stages {
        stage('Get Dashboards') {
            steps { script {
                println("Adding Nested Folder: ${params.FOLDER_NAME}") 
                // Initialize credentialsId variable
                def credentialsId
                if (params.ENVIRONMENT =='prod') {
                    GRAFANA_BASE_URL = "https://regeneron.grafana.net"
                    credentialsId = 'grafana-saas-prod-platform-api-key'
                    stack_id = '1210451'
                }
                else if (params.ENVIRONMENT =='dev') {
                    GRAFANA_BASE_URL = "https://regenerondev.grafana.net"
                    credentialsId = 'grafana-saas-dev-platform-api-key'
                    stack_id = '1250760'
                }
                else if (params.ENVIRONMENT =='test') {
                    GRAFANA_BASE_URL = "https://regenerontest.grafana.net"
                    credentialsId = 'grafana-saas-test-platform-api-key'
                    stack_id = '292932'
                }                

                dir('grafana-saas-automation') {
                    withCredentials([string(credentialsId: credentialsId, variable: 'GRAFANA_API_KEY')]) {
                        //Grafana API settings
                        sh """
                           python modules/Dashboards.py  get-dashboards --stack_id ${stack_id} --grafanabaseurl ${GRAFANA_BASE_URL}
                        """
                    }
                }
               }
            }
        }

    }
}