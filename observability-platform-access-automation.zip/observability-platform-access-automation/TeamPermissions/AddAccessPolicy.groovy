pipeline {
    agent { label 'cli-tools'}
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
    }
    // environment {
    // }
    parameters {
        string(name: 'STACK_ID', defaultValue: '', description: 'Stack ID')
        string(name: 'ACCESS_POLICY_NAME', defaultValue: '', description: 'Access Policy Name')
   }
    
    
    stages {
        stage('Create Access Policy') {
            steps { script {
                // Initialize credentialsId variable
                def credentialsId='grafana-cloud-access-policy-token'
                    withCredentials([string(credentialsId: credentialsId, variable: 'GC_AP_TOKEN')]) {
                        //Grafana API setting
                        sh """
                           python modules/GrafanaAutomation.py  ga-create-grafana-saas-access-policy --stack_id ${params.STACK_ID} --access_policy_name ${params.ACCESS_POLICY_NAME}
                        """
                    }
                }
               }
            }
        }

}