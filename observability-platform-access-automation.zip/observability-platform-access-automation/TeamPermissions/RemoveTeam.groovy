def ldapOUMappings = [
    'ldap-manager-password-devopsauthz': 'CN=svc.devops-authz-mgr,OU=System,OU=Regeneron Accounts,DC=regeneron,DC=regn,DC=com'
]
pipeline {
    agent { label 'cli-tools'}
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
    }
    environment {
        LDAP_HOST = "ldaps://regn-ldaps.regeneron.com"
        LDAP_PORT = 636
        CREDENTIALS_ID = "ldap-manager-password-devopsauthz"
        BASE_RAD_OU = "OU=Devopsauthz,OU=Application Groups,OU=Regeneron Groups,DC=regeneron,DC=regn,DC=com"
        GRAFANA_PROD_BASE_URL="https://regeneron.grafana.net"
        GRAFANA_NONPROD_BASE_URL="https://regenerondev.grafana.net"
    }
    parameters {
        string(name: 'BU_NAME', defaultValue: '', description: 'Name of Business Unit of Specific team')
        string(name: 'TEAM_NAME', defaultValue: '', description: 'Name of Team to add to Grafana SaaS, must beging with (ites|rit)-')
        string(name: 'DESCRIPTION', defaultValue: '', description: 'Description of Team')
        choice(name: 'ENVIRONMENT', choices:['prod','dev','test'], description: 'Select Environment either Prod or Dev or Test')
    }

    stages {
        stage('Remove Team') {
            steps { script {
                println("Adding New Team: ${params.TEAM_NAME}")
                
                def credentialsId
                
                // Determine credentialsId based on environment
                if (params.ENVIRONMENT == 'prod') {
                    credentialsId = 'grafana-saas-prod-platform-api-key'
                } else {
                    credentialsId = 'grafana-saas-nonprod-platform-api-key'
                } 


                    withCredentials([string(credentialsId: credentialsId, variable: 'GRAFANA_API_KEY')]) {
                        //Grafana API settings
                        sh """
                           python modules/Team.py  remove-team --name '${params.TEAM_NAME}' --environment '${params.ENVIRONMENT}' 
                        """
                    }
               }
            }
        }
    }
}