def ldapOUMappings = [
    'ldap-manager-password-devopsauthz': 'CN=svc.devops-authz-mgr,OU=System,OU=Regeneron Accounts,DC=regeneron,DC=regn,DC=com'
]
pipeline {
    agent { label 'cli-tools'}
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
    }
    environment {
        LDAP_HOST = "ldaps://regn-ldaps.regeneron.com"
        LDAP_PORT = 636
        CREDENTIALS_ID = "ldap-manager-password-devopsauthz"
        BASE_RAD_OU = "OU=Devopsauthz,OU=Application Groups,OU=Regeneron Groups,DC=regeneron,DC=regn,DC=com"
    }
    parameters {
        string(name: 'TEAM_ID', defaultValue: '', description: 'Team ID')
        string(name: 'FOLDER_UID', defaultValue: '', description: 'Folder UID')
        string(name: 'PERMISSION_ID', defaultValue: '', description: 'Permission ID')
        choice(name: 'ENVIRONMENT', choices:['dev','test','prod'], description: 'Select Environment either prod or dev or test')     
    }
    
    
    stages {
        stage('Create Nested Folder') {
            steps { script {
                println("Adding Nested Folder: ${params.FOLDER_NAME}") 
                // Initialize credentialsId variable
                def credentialsId
                if (params.ENVIRONMENT =='prod') {
                    GRAFANA_BASE_URL = "https://regeneron.grafana.net"
                    credentialsId = 'grafana-saas-prod-platform-api-key'
                }
                else if (params.ENVIRONMENT =='dev') {
                    GRAFANA_BASE_URL = "https://regenerondev.grafana.net"
                    credentialsId = 'grafana-saas-dev-platform-api-key'
                }
                else if (params.ENVIRONMENT =='test') {
                    GRAFANA_BASE_URL = "https://regenerontest.grafana.net"
                    credentialsId = 'grafana-saas-test-platform-api-key'
                }                

                    withCredentials([string(credentialsId: credentialsId, variable: 'GRAFANA_API_KEY')]) {
                        //Grafana API settings
                        sh """
                           python modules/GrafanaAutomation.py  ga-folder-permissions --team_id ${TEAM_ID} --folder_uid ${FOLDER_UID} --permission_id ${PERMISSION_ID} --grafana_base_url ${GRAFANA_BASE_URL}
                        """
                    }
               }
            }
        }

    }
}