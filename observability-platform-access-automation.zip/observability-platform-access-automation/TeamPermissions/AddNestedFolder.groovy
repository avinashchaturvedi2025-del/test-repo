def ldapOUMappings = [
    'ldap-manager-password-devopsauthz': 'CN=svc.devops-authz-mgr,OU=System,OU=Regeneron Accounts,DC=regeneron,DC=regn,DC=com'
]
pipeline {
    agent { label 'cli-tools'}
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
    }
    environment {
        LDAP_HOST = "ldaps://regn-ldaps.regeneron.com"
        LDAP_PORT = 636
        CREDENTIALS_ID = "ldap-manager-password-devopsauthz"
        BASE_RAD_OU = "OU=Devopsauthz,OU=Application Groups,OU=Regeneron Groups,DC=regeneron,DC=regn,DC=com"
    }
    parameters {
        string(name: 'BU_NAME', defaultValue: '', description: 'Name of Business Unit of Specific team')
        string(name: 'FOLDER_NAME', defaultValue: '', description: 'Name of Team to add to Grafana SaaS, must beging with (ites|rit)-')
        string(name: 'ENVIRONMENT', defaultValue: 'Dev', description: 'Name of the Environment.')     
    }
    
    
    stages {
        stage('Create Nested Folder') {
            steps { script {
                println("Adding Nested Folder: ${params.FOLDER_NAME}") 
                // Initialize credentialsId variable
                def credentialsId
                if (params.ENVIRONMENT =='prod') {
                    GRAFANA_BASE_URL = "https://regeneron.grafana.net"
                    credentialsId = 'grafana-saas-prod-platform-api-key'
                }
                else if (params.ENVIRONMENT =='dev') {
                    GRAFANA_BASE_URL = "https://regenerondev.grafana.net"
                    credentialsId = 'grafana-saas-dev-platform-api-key'
                }
                else if (params.ENVIRONMENT =='test') {
                    GRAFANA_BASE_URL = "https://regenerontest.grafana.net"
                    credentialsId = 'grafana-saas-test-platform-api-key'
                }                

                    withCredentials([string(credentialsId: credentialsId, variable: 'GRAFANA_API_KEY')]) {
                        //Grafana API settings
                        sh """
                           python modules/GrafanaAutomation.py  ga-nested-folder --bu_name ${BU_NAME} --folder_name ${FOLDER_NAME} --grafana_base_url ${GRAFANA_BASE_URL}
                        """
                    }
               }
            }
        }

    }
}