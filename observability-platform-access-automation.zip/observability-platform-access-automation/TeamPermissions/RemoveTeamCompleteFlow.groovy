def ldapOUMappings = [
    'ldap-manager-password-devopsauthz': 'CN=svc.devops-authz-mgr,OU=System,OU=Regeneron Accounts,DC=regeneron,DC=regn,DC=com'
]
pipeline {
    agent { label 'cli-tools'}
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
    }
    environment {
        LDAP_HOST = "ldaps://regn-ldaps.regeneron.com"
        LDAP_PORT = 636
        CREDENTIALS_ID = "ldap-manager-password-devopsauthz"
        BASE_RAD_OU = "OU=Devopsauthz,OU=Application Groups,OU=Regeneron Groups,DC=regeneron,DC=regn,DC=com"
    }
    parameters {
        string(name: 'BU_NAME', defaultValue: '', description: 'Name of Business Unit of Specific team')
        string(name: 'TEAM_NAME', defaultValue: '', description: 'Name of Team to add to Grafana SaaS, must beging with (ites|rit)-')
        choice(name: 'ENVIRONMENT', choices:['dev','test','prod'], description: 'Select Environment either Prod or NonProd')
    }
    
    
    stages {
        stage('Remove Team') {
            steps { script {
                println("Adding New Team: ${params.TEAM_NAME}") 
                // Initialize credentialsId variable
                def credentialsId
                
                // Determine credentialsId based on environment
                if (params.ENVIRONMENT =='prod') {
                    GRAFANA_BASE_URL = "https://regeneron.grafana.net"
                    credentialsId = 'grafana-saas-prod-platform-api-key'
                }
                else if (params.ENVIRONMENT =='dev') {
                    GRAFANA_BASE_URL = "https://regenerondev.grafana.net"
                    credentialsId = 'grafana-saas-dev-platform-api-key'
                }
                else if (params.ENVIRONMENT =='test') {
                    GRAFANA_BASE_URL = "https://regenerontest.grafana.net"
                    credentialsId = 'grafana-saas-test-platform-api-key'
                }
                def ldapcredentialsId = 'ldap-manager-password-devopsauthz' 
                def gcaptcredentialsId='grafana-cloud-access-policy-token' 
                
                    withCredentials([string(credentialsId: credentialsId, variable: 'GRAFANA_API_KEY'), string(credentialsId: ldapcredentialsId, variable: 'BINDING_PW'), string(credentialsId: gcaptcredentialsId, variable: 'GC_AP_TOKEN')]) {
                        def binding_dn = ldapOUMappings[ldapcredentialsId]
                        //Grafana API settings
                        sh """
                           export "BINDING_DN=${binding_dn}"
                           python modules/Team.py remove-team-complete-flow --bu_name '${params.BU_NAME}' --team_name '${params.TEAM_NAME}' --environment '${params.ENVIRONMENT}' --grafana_base_url ${GRAFANA_BASE_URL}
                        """
                    }
               }
            }
        }
    }
}