@Library('DevOpsLib@grafana-saas-automation') _

import hudson.util.Secret
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import groovy.json.JsonSlurperClassic
import com.regeneron.radit.devops.pmp.PMP
import com.regeneron.radit.devops.aws.AwsUtil
import com.regeneron.radit.devops.python.PythonLibraries
import com.regeneron.radit.devops.snow.GrafanaSaaSAutomation

def awsUtil = new AwsUtil()
def jsonSlurper = new JsonSlurper()
def successQueueUrl = "https://sqs.us-east-1.amazonaws.com/154919775133/snow-automation-rit-shared-dev-success"

pipeline {
    agent any
    environment {
      PMP_TOKEN = credentials('pmp-snow-token')
      SNOW_API_URL = "https://regeneron.service-now.com/api/rep/workspace_util/ritm"
    }
    parameters {
        string(name: 'payload',description: 'Payload from lambda function.')
    }
    stages {
        stage('Trigger job') {
          steps {
            script {
              print("Input payload : ${payload}")
              def payload = jsonSlurper.parseText(payload)
              def jenkinsPayload = payload.input ? payload.input : '{}'
              assert payload.taskToken != "" && payload.taskToken != null : "taskToken is empty."
              jenkinsPayload.taskToken = payload.taskToken
              (new GrafanaSaaSAutomation()).triggerRouter(jenkinsPayload)
            }
          }
        }
    }
    post { success { script {
          def payload = jsonSlurper.parseText(payload)
          def sfnCallback = """{"status": "Success", "build": "${BUILD_URL}"}"""
          awsUtil.sendSuccessActivityTask(payload.taskToken,  sfnCallback)
          def sqsMessage = [:]
          sqsMessage['payload'] = payload.input
          def message = JsonOutput.toJson(sqsMessage)
          String response = sh(returnStdout: true, script: """aws sqs send-message --queue-url ${successQueueUrl} --message-body '${message}'""")
          def json = new JsonSlurperClassic().parseText(response)
          println("Sent message with MessageId: ${json.MessageId} to ${successQueueUrl}")
        }}
        failure{ script{
          def payload = jsonSlurper.parseText(payload)
          def sfnCallbackCause = [:]
          sfnCallbackCause['buildUrl'] = BUILD_URL
          sfnCallbackCause['payload'] = payload
          awsUtil.sendFailureActivityTask(payload.taskToken, "Failed", JsonOutput.toJson(sfnCallbackCause))
        }}
    }
}

private void snowTicket(String ticket, String message, String reason, String status) {
  print("message:${message}")
  print("reason:${reason}")
  print("status:${status}")
  pmp = new PMP(PMP_TOKEN)
  creds = pmp.getAccounts().find() { it.resource_name ==~ /\[PROD\].*/}

  pyLib = new PythonLibraries()
  pyLib.setCredentials(
    new Secret(creds.account_name),
    new Secret(creds.account_password)
  )

  status = pyLib.updateSnowTicket("", ticket, status, message, reason, env.SNOW_API_URL)
  print(status)
}

