def ldapOUMappings = [
    'ldap-manager-password-devopsauthz': 'CN=svc.devops-authz-mgr,OU=System,OU=Regeneron Accounts,DC=regeneron,DC=regn,DC=com'
]
pipeline {
    agent { label 'cli-tools'}
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
    }
    environment {
        LDAP_HOST = "ldaps://regn-ldaps.regeneron.com"
        LDAP_PORT = 636       
    }
    parameters {
        string(name: 'GROUP_NAME', defaultValue: '', description: 'Name of group to remove users from')
        string(name: 'USER_LIST', defaultValue: '', description: 'Comma separated list of users to remove from group')
    }

    stages {
        stage('Remove users from group') {
            steps { script {
                println("Removing users: ${params.USER_LIST}")
                println("From group: ${params.GROUP_NAME}")
                    for (user in params.USER_LIST.split(',')) {
                        def trimedUser = user.trim()
                        
                        def credentialsId = 'ldap-manager-password-devopsauthz' 
                
                        if (trimedUser != "") {
                            withCredentials([string(credentialsId: credentialsId, variable: 'BINDING_PW')]) {
                                def binding_dn = ldapOUMappings[credentialsId]
                                sh """
                                    export "BINDING_DN=${binding_dn}"
                                    python modules/GrafanaAutomation.py ga-remove-user-from-group --group '${params.GROUP_NAME}' --user '${trimedUser}'
                                """
                            }
                        }
                    }
            }
         }
      }
    }
}