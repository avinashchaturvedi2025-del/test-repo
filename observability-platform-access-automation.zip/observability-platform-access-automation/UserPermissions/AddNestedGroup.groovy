def ldapOUMappings = [
    'ldap-manager-password-devopsauthz': 'CN=svc.devops-authz-mgr,OU=System,OU=Regeneron Accounts,DC=regeneron,DC=regn,DC=com'
    ]
def binding_dn = ""
pipeline {
    agent { label 'cli-tools'}
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
    }
    environment {
        LDAP_HOST = "ldaps://regn-ldaps.regeneron.com"
        LDAP_PORT = 636
    }
    parameters {
        string(name: 'GROUP_NAME', defaultValue: '', description: 'Name of group to add to OU, must beging with (ites|rit)')
        string(name: 'PARENT_GROUP_NAME', defaultValue: '', description: 'Name of parent group to add to OU, must beging with (ites|rit)')
        string(name: 'USER_LIST', defaultValue: '', description: 'Comma separated list of users to add to group')
        string(name: 'DESCRIPTION', defaultValue: '', description: 'Description of AD Group')
    }
    stages {
        stage('Create Group') {
            steps { script {
                println("Adding group name: ${params.GROUP_NAME}")
                println("To OU: ${params.BASE_RAD_OU}")
                println("With users: ${params.USER_LIST}")
                // Initialize credentialsId variable
                def credentialsId = 'ldap-manager-password-devopsauthz'   
                // assert params.GROUP_NAME ==~ /^(ites|rit|DF).+/
                    withCredentials([string(credentialsId: credentialsId, variable: 'BINDING_PW')]) {
                        binding_dn = ldapOUMappings[credentialsId]
                        sh """
                            export "BINDING_DN=${binding_dn}"
                            python modules/ldapManager.py create-group-in-ou --groupname '${params.GROUP_NAME}' --description '${params.DESCRIPTION}'
                        """
                        for (user in params.USER_LIST.split(',')) {
                            def trimedUser = user.trim()
                            if (trimedUser != "") {
                                binding_dn = ldapOUMappings[credentialsId]
                                sh """
                                    export "BINDING_DN=${binding_dn}"
                                    python modules/GrafanaAutomation.py ga-add-user-to-group --group '${params.PARENT_GROUP_NAME}' --user '${trimedUser}' --user_type 'group'
                                """
                            }
                        }
                    }
            }
          }
        }
    }
}
