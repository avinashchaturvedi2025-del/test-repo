import hudson.model.User
import jenkins.model.Jenkins

pipeline {
  agent { label 'default'}
  options {
    buildDiscarder(logRotator(numToKeepStr: '10'))
  }
  
  parameters {
    string(name: 'LDAP_HOST',
           description: 'LDAP HOST URL', defaultValue: "ldaps://regn-ldaps.regeneron.com")
    string(name: 'LDAP_PORT',
           description: 'LDAP HOST PORT', defaultValue: "636")
    string(name: 'JENKINS_GROUP',
           description: 'Name of the Jenkins Group', defaultValue: "authenticated")
    string(name: 'GIT_REPO',
           description: 'Name of the GIT Repo', defaultValue: "ssh://git@ritscm.regeneron.com/devops/jenkins-automation.git")            
    string(name: 'GIT_CHECKOUT_BRANCH',
           description: 'Name of the GIT Branch', defaultValue: "master")   
    string(name: 'GIT_BASE_DIR',
           description: 'Base dir of GIT Repo', defaultValue: "jenkins-automation")       
    string(name: 'GIT_FILEPATH',
           description: 'File path where the update needs to be pushed', defaultValue: "CloudBees-On-Boarding/Database/projects.yml")            
  }

  environment {
    USERS_IN_GROUP = ""
  }
  
  stages {  
    stage('Extract users') {
        steps {
            script {
                def groupName = "${params.JENKINS_GROUP}" 
                def group = Jenkins.instance.securityRealm.loadGroupByGroupname(groupName, false)
                USERS_IN_GROUP = group.members.collect { "\"${it}\"" }
            }
        }
    }
    
    stage('Fetch LDAP In-active Users') { 
        steps { 
            script {
                withCredentials([usernamePassword(credentialsId: 'ldap-creds',
                                    usernameVariable: 'BINDING_DN',
                                    passwordVariable: 'BINDING_PW')]) {
                    sh "pip install ldap3 tabulate click"
                    def result = sh(script: "python3 ldap-management/ldap-manager.py lookup-disabled-accounts --user_name_list \'${USERS_IN_GROUP}\'", returnStatus: true)
                    sh "cat deactivated_users_list.txt"                        
                }
            }
        }  
    }
    
    stage('Delete Users from Jenkins') {
        steps {
            script {
                def deactivateUsersListFile = readFile('deactivated_users_list.txt')
                def deactivatedUsersList = new groovy.json.JsonSlurper().parseText(deactivateUsersListFile.replace("\'", "\""))

                deactivatedUsersList.each { user ->
                    def jenkinsUser = User.get(user)
                    if (jenkinsUser) {
                        jenkinsUser.delete()
                        echo "Deleted user: ${user} from Jenkins"
                    } else {
                        echo "User: ${user} not found in Jenkins"
                    }
                }
            }
        }
    }
    
    stage('Updating Database projects.yml file') {
        steps { 
            script {
                sshagent (credentials:['bitbucket-publish']) {
                    def deactivateUsersListFile = readFile('deactivated_users_list.txt')
                    def deactivatedUsersList = new groovy.json.JsonSlurper().parseText(deactivateUsersListFile.replace("\'", "\""))
                    sh "git clone ${GIT_REPO}" 
                    dir("${GIT_BASE_DIR}") {
                        sh "git checkout ${GIT_CHECKOUT_BRANCH}"

                        def projectsFile = readFile("${GIT_FILEPATH}")
                        def projectsLines = projectsFile.split('\n')

                        def updatedLines = projectsLines.findAll { line -> 
                            !deactivatedUsersList.any{user -> 
                                line.contains("- "+user)
                            }
                        }

                        writeFile file: "${GIT_FILEPATH}", text: updatedLines.join('\n')
                        withCredentials([sshUserPrivateKey(credentialsId: 'bitbucket-publish',
                                         usernameVariable: 'SSH_USER_NAME',
                                         keyFileVariable: 'SSH_KEY')]) {
                            sh """
                            git config user.name ${SSH_USER_NAME}
                            git config user.email '${SSH_USER_NAME}@regeneron.com'
                            git remote get-url origin
                            git add ${GIT_FILEPATH}
                            """
                        }
                        
                        def commitStatus = sh(script: "git commit -m '${BUILD_TAG}'",
                                      returnStatus: true)
                        if (commitStatus == 0) {
                            sh "git push origin ${GIT_CHECKOUT_BRANCH}"
                            pushStatus = true
                        }
                    }
                }
            }
        }
    }
  }
}