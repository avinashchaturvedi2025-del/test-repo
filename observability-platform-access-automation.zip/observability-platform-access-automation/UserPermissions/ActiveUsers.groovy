@Library('DevOpsLib') _

import hudson.model.User
import jenkins.model.Jenkins

pipeline {
  agent any
  triggers {
    cron('H 5 * * 0')
  }
  options {
    buildDiscarder(logRotator(numToKeepStr: '10'))
  }
  
  parameters {
    choice(name: 'CREDENTIALS_ID', choices: ['ldap-manager-password-devopsauthz'], description: 'Jenkins credentials id for ldap-manager password')
    string(name: 'LDAP_HOST',
           description: 'LDAP HOST URL', defaultValue: "ldaps://regn-ldaps.regeneron.com")
    string(name: 'LDAP_PORT',
           description: 'LDAP HOST PORT', defaultValue: "636")
    string(name: 'JENKINS_GROUP',
           description: 'Name of the Jenkins Group', defaultValue: "authenticated")          
  }

  environment {
    USERS_IN_GROUP = ""
  }
  
  stages {  
    stage('Extract users') {
        steps {
            script {
                def groupName = "${params.JENKINS_GROUP}" 
                def group = Jenkins.instance.securityRealm.loadGroupByGroupname(groupName, false)
                USERS_IN_GROUP = group.members.findAll { it != 'admin' }.collect { "\"${it}\"" }
            }
        }
    }
    
    stage('Fetch LDAP In-active Users') { 
        steps { 
            script {
                withCredentials([string(credentialsId: params.CREDENTIALS_ID, variable: 'BINDING_PW')]) {
                    //ldapvars is defined in sharedlib vars directory
                    def binding_dn = ldapvars.ldapOUMappings()[params.CREDENTIALS_ID]
                    sh """
                    set +x
                    export "BINDING_DN=${binding_dn}"
                    python3 grafana-saas-automation/modules/Ldap-manager.py lookup-disabled-accounts --user_name_list \'${USERS_IN_GROUP}\'
                    cat deactivated_users_list.txt
                    cat active_users_list.txt
                    echo "Deactivated users count :`cat deactivated_users_list.txt | wc -l`"               
                    echo "Active users count :`cat active_users_list.txt | wc -l`"               
                    """                     
                }
            }
        }  
    }
    
  }
    post{
        always {
            script {
                def activeUsersFile = readFile 'active_users_list.txt'
                def activeUsersCount = activeUsersFile.split('\n').size()
                archiveArtifacts artifacts: 'deactivated_users_list.txt', onlyIfSuccessful: true
                archiveArtifacts artifacts: 'active_users_list.txt', onlyIfSuccessful: true
                emailext(
                subject: "Active users in Jenkins Prod",
                attachmentsPattern: 'active_users_list.txt',
                to: 'geo-it-devops-notify@regeneron.com,thirupathireddy.edla@regeneron.com,himagiri.munduri@regeneron.com',
                mimeType: 'text/html',
                body: """ 
                Active users count in Jenkins Prod : <b>${activeUsersCount}</b><br>Please find the attached file for the list of active users.
                <br><br>You can view the build details at: ${env.BUILD_URL}
                """
            )
            }
        }
    }
}
