def ldapOUMappings = [
    'ldap-manager-password-devopsauthz': 'CN=svc.devops-authz-mgr,OU=System,OU=Regeneron Accounts,DC=regeneron,DC=regn,DC=com'    
]
pipeline {
    agent { label 'cli-tools'}
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
    }
    environment {
        LDAP_HOST = "ldaps://regn-ldaps.regeneron.com"
        LDAP_PORT = 636
    }
    parameters {
        string(name: 'GROUP_NAME', defaultValue: '', description: 'Name of group to add users to')
        string(name: 'USER_LIST', defaultValue: '', description: 'Comma separated list of users to add to group')
    }

    stages {
        stage('Add users to group') {
            steps { script {
                    for (user in params.USER_LIST.split(',')) {
                        def trimedUser = user.trim()
                        if (trimedUser != "") {
                            // Initialize credentialsId variable
                            def credentialsId = 'ldap-manager-password-devopsauthz' 
                            withCredentials([string(credentialsId: credentialsId, variable: 'BINDING_PW')]) {
                                def binding_dn = ldapOUMappings[credentialsId]
                                sh """
                                    export "BINDING_DN=${binding_dn}"
                                    python modules/GrafanaAutomation.py  ga-add-user-to-group --group '${params.GROUP_NAME}' --user '${trimedUser}'
                                """
                            }
                        }
                    }
               }
            }

        }
    }
}
