def ldapOUMappings = [
    'ldap-manager-password-devopsauthz': 'CN=svc.devops-authz-mgr,OU=System,OU=Regeneron Accounts,DC=regeneron,DC=regn,DC=com'
]
pipeline {
    agent { label 'cli-tools'}
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
    }
    environment {
        LDAP_HOST = "ldaps://regn-ldaps.regeneron.com"
        LDAP_PORT = 636
        BASE_RAD_OU = "OU=Devopsauthz,OU=Application Groups,OU=Regeneron Groups,DC=regeneron,DC=regn,DC=com"
        CREDENTIALS_ID = "ldap-manager-password-devopsauthz" 
    }
    parameters {
        string(name: 'GROUP_NAME', defaultValue: '', description: 'Name of group to add to OU, must beging with (ites|rit)-')
        string(name: 'DESCRIPTION', defaultValue: '', description: 'Description of AD Group')
    }

    stages {
        stage('Create Group') {
            steps { script {
                // Initialize credentialsId variable
                def credentialsId = 'ldap-manager-password-devopsauthz'    
                
                    withCredentials([string(credentialsId: credentialsId, variable: 'BINDING_PW')]) {
                        def binding_dn = ldapOUMappings[credentialsId]
                        sh """
                            export "BINDING_DN=${binding_dn}"
                            python modules/GrafanaAutomation.py ga-create-group-in-ou --group_name '${params.GROUP_NAME}' --ou '${env.BASE_RAD_OU}' --description '${params.DESCRIPTION}'
                        """
                    }
                }
            }
        }
    }
}