terraform {
  required_providers {
    # The source is usually 'grafana/grafana'
    grafana = {
      source  = "grafana/grafana"
      version = ">= 4.10.0" # Specify your desired version constraint
    }
    ldap = {
      source  = "l-with/ldap"
      version = ">= 0.4"
    }
  }
}

provider "grafana" {
    url = trimsuffix(trimspace(var.grafana_url), "/")
    #auth = var.grafana_auth
    #auth = jsondecode(data.aws_secretsmanager_secret_version.pw.secret_string)["token"]
    auth = jsondecode(data.aws_secretsmanager_secret_version.grafana_token.secret_string)["token"]

    cloud_access_policy_token = var.grafana_cloud_api_key
}

variable "grafana_url" {
    description = "Grafana url"
    type = string
}

variable "grafana_auth" {
  description = "Grafana service account token"
  type        = string
  sensitive   = true
}

variable "grafana_cloud_api_key" {
  description = "Grafana Cloud Access Policy token"
  type        = string
  sensitive   = true
}

variable "bind_password" {
  description = "LDAP bind password (set via TF_VAR_bind_password environment variable)"
  type        = string
  sensitive   = true
}

# variable "grafana_auth" {
#     description = "Grafana credentails"
#     type = string
# }