
data "aws_secretsmanager_secret_version" "grafana_token" {
  secret_id = "grafana-cloud/token"
}


//--------------------------------------------------------------------
// Modules
module "module_notification_policy" {
  source  = "terraform.regeneron.com/regeneron/module-notification-policy/terraform"
  version = "1.0.4"

  disable_provenance = "true"
  policy_path = "./policy.yaml"
  
  # This forces the notification policy to wait
  depends_on = [module.riop-contact-point]
}

module "riop-contact-point" {
  source  = "terraform.regeneron.com/regeneron/riop-contact-point/module"
  version = "1.0.2"

  contact_point_path = "./contact_point/contact_point.yaml"

}


module "riop-alerts" {
  source  = "terraform.regeneron.com/regeneron/riop-alerts/module"
  version = "1.0.5"
  alerts_path = "./alerts"
}

module "riop-datasource" {
  source  = "terraform.regeneron.com/regeneron/riop-datasource/module"
  version = "1.0.3"
  config_path = "./datasource/datasource.yaml"

  grafana_url          = var.grafana_url
  grafana_auth         = var.grafana_auth
  grafana_cloud_api_key = var.grafana_cloud_api_key
}

# okta module version update
module "riop-okta-group" {
  source  = "terraform.regeneron.com/regeneron/riop-okta-group/module"
  version = "1.0.33"
  groups_config_path = "./ad_group/groups.yaml"
  bind_password = var.bind_password
}


module "riop-team" {
 source  = "terraform.regeneron.com/regeneron/riop-team/module"
 version = "1.0.14"

 teams_config_path     = "./teams/teams.yaml"
 grafana_url           = var.grafana_url
 grafana_auth = var.grafana_auth

 create_teams = false
 rbac_enabled = true
}

module "riop-folder" {
  source  = "terraform.regeneron.com/regeneron/riop-folder/module"
  version = "1.0.4"
  grafana_url          = var.grafana_url
  grafana_auth         = var.grafana_auth
  folder_config_path = "./folders/folders.yaml"
  permissions_config_path = "./folders/permissions.yaml"

}
